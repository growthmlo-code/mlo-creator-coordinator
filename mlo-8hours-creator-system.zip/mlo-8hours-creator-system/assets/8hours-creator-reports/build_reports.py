#!/usr/bin/env python3
"""Build per-creator 8HOURS performance reports (static) from creators.json.

  python3 build_reports.py            -> writes ./dist (index + one folder per creator)

Creator-safe only: NO ROAS / CPA / spend ever reaches the page.
Videos & frames are remote Atria URLs (no downloads).
"""
import hashlib, html, json, os, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "creators.json")
HISTORY = os.path.join(HERE, "history.json")   # previous snapshot per slug, for trend deltas (written by the refresh task)
DIST = os.path.join(HERE, "dist")
CDN = "https://cdn.tryatria.com/analytics/2974be40b9764b00bcd0c5c75878e4f7/"
SALT = "8h0urs-mlo-private-2026-k9x2"           # keeps per-creator URLs unguessable; keep private

def token(slug):
    return hashlib.sha1((slug + "|" + SALT).encode()).hexdigest()[:10]

BENCH = {"hook": "", "ctr": ""}   # account-average benchmarks, set from creators.json in main()

def e(s): return html.escape(str(s if s is not None else ""))

COMMISSION_RATE = 0.10  # simulated until Trybe is wired up

def comm(value_str):
    """Simulated creator payout = COMMISSION_RATE of the conversion value string (e.g. '€1,663')."""
    n = num(value_str)
    if n is None:
        return "—"
    return "€" + format(int(round(n * COMMISSION_RATE)), ",d")

def num(s):
    """Parse '€1,663' / '43%' / '1.20x' -> float, or None."""
    try:
        return float(str(s).replace("€", "").replace(",", "").replace("%", "").replace("x", "").strip())
    except (ValueError, AttributeError):
        return None

def delta(cur, prev):
    """Small ▲/▼ chip vs previous period. Empty string when there is no comparable history."""
    c, p = num(cur), num(prev)
    if c is None or p is None or p == 0:
        return ""
    pct = (c - p) / p * 100
    if abs(pct) < 1:
        return '<span class="delta flat">→ flat</span>'
    arrow, cls = ("▲", "up") if pct > 0 else ("▼", "down")
    return '<span class="delta ' + cls + '">' + arrow + " " + format(abs(round(pct)), "d") + "% vs last</span>"

CSS = """
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');
:root{
  --bg:#121111; --bg-panel:rgba(255,255,255,0.038); --bg-panel-2:rgba(255,255,255,0.06); --panel-border:rgba(255,255,255,0.09);
  --accent:#9F86B8; --accent-glow:rgba(159,134,184,0.28);
  --good:#7FD1A6; --warn:#E6C06A; --bad:#E08A7A;
  --text:#F3EFEA; --text-dim:#9A938A;
  --serif:"Playfair Display",Georgia,serif; --mono:"JetBrains Mono",monospace; color-scheme:dark;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:"Plus Jakarta Sans",system-ui,sans-serif;font-size:15px;line-height:1.5}
section{position:relative;width:100%;min-height:100vh;padding:52px 80px 76px;display:flex;flex-direction:column;justify-content:center;border-bottom:1px solid rgba(255,255,255,0.06);overflow:hidden}
@media(max-width:640px){section{padding:40px 20px 60px;min-height:auto}}
.glow{position:absolute;background:radial-gradient(circle,var(--accent-glow) 0%,transparent 65%);pointer-events:none;z-index:0}
section>*{position:relative;z-index:1}
section>.glow{position:absolute;z-index:0}
.logo-bar{display:flex;align-items:center;gap:8px;margin-bottom:30px}
.logo-dot{width:8px;height:8px;border-radius:50%;background:var(--accent);box-shadow:0 0 10px var(--accent-glow);flex-shrink:0}
.logo-text{font-size:11px;font-weight:700;letter-spacing:2.5px;text-transform:uppercase;color:var(--text-dim)}
.sec-head{display:flex;align-items:baseline;gap:14px;margin-bottom:6px;flex-wrap:wrap}
.sec-num{font-family:var(--mono);font-size:12px;color:var(--accent);font-weight:600}
h1{font-size:clamp(34px,5vw,50px);font-weight:800;line-height:1.08;letter-spacing:-0.5px;margin-bottom:14px;text-wrap:balance}
h1 .serif{font-family:var(--serif);font-style:italic;font-weight:400;color:var(--accent)}
h2{font-size:27px;font-weight:800;letter-spacing:-0.3px;text-wrap:balance}
.subtitle{font-size:15px;color:var(--text-dim);line-height:1.55;max-width:640px;margin:8px 0 24px}
.subtitle b{color:var(--text)}
.read-badge{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;letter-spacing:0.5px;color:var(--text-dim);border:1px solid var(--panel-border);border-radius:999px;padding:5px 12px;margin-bottom:20px;align-self:flex-start}
.meta-row{display:flex;gap:44px;flex-wrap:wrap;margin-top:36px}
.meta-item{display:flex;flex-direction:column;gap:5px}
.meta-label{font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:var(--text-dim)}
.meta-value{font-size:14px;font-weight:600}
.creator-badge{display:flex;align-items:center;gap:14px;margin-bottom:26px}
.creator-avatar{width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--accent) 0%,#6B5486 100%);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#1A1222;flex-shrink:0;box-shadow:0 0 22px var(--accent-glow)}
.creator-name{font-size:17px;font-weight:700}
.creator-role{font-size:12px;color:var(--text-dim);margin-top:2px}
.pill{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-weight:700;letter-spacing:0.4px;text-transform:uppercase;padding:5px 12px;border-radius:999px;white-space:nowrap}
.pill-scale{background:rgba(127,209,166,0.12);border:1px solid rgba(127,209,166,0.4);color:var(--good)}
.pill-test{background:rgba(230,192,106,0.1);border:1px solid rgba(230,192,106,0.35);color:var(--warn)}
.pill-pause{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.14);color:var(--text-dim)}
.metric-row{display:flex;gap:14px;flex-wrap:wrap;margin-top:14px}
.metric-chip{background:var(--bg-panel);border:1px solid var(--panel-border);border-radius:12px;padding:16px 20px;min-width:140px}
.metric-chip.hero{border-color:rgba(159,134,184,0.35);background:linear-gradient(135deg,rgba(159,134,184,0.1),rgba(159,134,184,0.03))}
.mc-label{font-size:10px;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-dim)}
.mc-value{font-size:24px;font-weight:800;margin-top:4px;font-variant-numeric:tabular-nums}
.mc-note{font-size:11.5px;color:var(--text-dim);margin-top:3px}
.vid-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:18px;margin-top:18px}
@media(max-width:640px){.vid-grid{grid-template-columns:1fr}}
.vid-card{background:var(--bg-panel);border:1px solid var(--panel-border);border-radius:18px;overflow:hidden;display:flex;flex-direction:column}
.vid-card.scale{border-color:rgba(127,209,166,0.3)}
.vid-card.test{border-color:rgba(230,192,106,0.28)}
.vid-card.pause{border-color:var(--panel-border)}
.vid-thumb{position:relative;aspect-ratio:9/16;background:#17141C;display:flex;align-items:center;justify-content:center;overflow:hidden}
.vid-thumb video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.vid-code{position:absolute;top:12px;left:12px;z-index:2;font-family:var(--mono);font-size:10px;color:rgba(255,255,255,0.55);background:rgba(0,0,0,0.55);padding:3px 8px;border-radius:6px}
.vid-status-badge{position:absolute;top:12px;right:12px;z-index:2}
.vid-sound{position:absolute;bottom:10px;right:10px;z-index:3;background:rgba(0,0,0,0.6);color:#fff;border:0;border-radius:999px;font:600 11px "Plus Jakarta Sans",sans-serif;padding:6px 11px;cursor:pointer}
.vid-hook-overlay{position:absolute;bottom:0;left:0;right:0;z-index:2;padding:46px 16px 14px;background:linear-gradient(to top,rgba(0,0,0,0.9) 0%,transparent 100%);font-family:var(--serif);font-style:italic;font-size:14px;line-height:1.4;color:rgba(255,255,255,0.92);pointer-events:none}
.vid-body{padding:14px 18px 18px}
.vid-angle{font-size:12px;color:var(--text-dim);margin-bottom:10px}
.vid-metrics{display:flex;border-top:1px solid rgba(255,255,255,0.07);padding-top:11px}
.vid-metric{flex:1;text-align:center;border-right:1px solid rgba(255,255,255,0.07);padding:0 8px}
.vid-metric:first-child{text-align:left;padding-left:0}
.vid-metric:last-child{border-right:none}
.vm-label{font-size:10px;text-transform:uppercase;letter-spacing:0.7px;color:var(--text-dim)}
.vm-value{font-size:17px;font-weight:800;margin-top:3px;font-variant-numeric:tabular-nums}
.up{color:var(--good)}.down{color:var(--bad)}.flat{color:var(--text-dim)}
.mc-note .delta,.vm-note .delta{font-weight:700}
.delta.up{color:var(--good)}.delta.down{color:var(--bad)}.delta.flat{color:var(--text-dim)}
.vm-note{font-size:10px;color:var(--text-dim);margin-top:2px;letter-spacing:0.2px}
.cta-block{display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;background:linear-gradient(135deg,rgba(159,134,184,0.12),rgba(159,134,184,0.03));border:1px solid rgba(159,134,184,0.35);border-radius:16px;padding:22px 26px;margin-top:22px}
.cta-block .cta-t{font-size:17px;font-weight:800}
.cta-block .cta-s{font-size:13px;color:var(--text-dim);margin-top:3px}
.cta-block .cta-btn{background:var(--accent);color:#1A1222;font-weight:800;font-size:14px;padding:12px 20px;border-radius:999px;white-space:nowrap}
.callout{background:var(--bg-panel);border-left:3px solid var(--accent);border-radius:10px;padding:15px 20px;margin-top:18px;font-size:13.5px;line-height:1.55}
.callout b{color:var(--text)}
.formula-strip{display:grid;grid-template-columns:repeat(var(--n,5),1fr);gap:10px;margin-top:20px}
@media(max-width:760px){.formula-strip{grid-template-columns:1fr;gap:8px}}
.fstep{background:var(--bg-panel);border:1px solid var(--panel-border);border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:8px}
.fstep-top{display:flex;align-items:center;justify-content:space-between}
.fstep-time{font-family:var(--mono);font-size:10px;color:var(--text-dim)}
.fstep-no{width:20px;height:20px;border-radius:50%;background:var(--accent);color:#1A1222;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center}
.fstep-label{font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:0.4px}
.fstep-quote{font-family:var(--serif);font-style:italic;font-size:12.5px;line-height:1.4;color:rgba(159,134,184,0.85)}
.ki-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}
@media(max-width:760px){.ki-grid{grid-template-columns:1fr}}
.ki-card{background:var(--bg-panel);border:1px solid var(--panel-border);border-radius:16px;padding:24px 26px}
.ki-card.keep{border-color:rgba(127,209,166,0.26)}
.ki-card.push{border-color:rgba(230,192,106,0.24)}
.ki-title{display:flex;align-items:center;gap:9px;font-size:15px;font-weight:800;margin-bottom:16px}
.ki-title .dot{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0}
.ki-card.keep .dot{background:rgba(127,209,166,0.15)}
.ki-card.push .dot{background:rgba(230,192,106,0.14)}
.ki-list{list-style:none;display:flex;flex-direction:column}
.ki-list li{padding:11px 0;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;flex-direction:column;gap:3px}
.ki-list li:last-child{border-bottom:none;padding-bottom:0}
.ki-item{font-size:14px;font-weight:600}
.ki-why{font-size:12px;color:var(--text-dim);line-height:1.45}
.brief-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:18px}
@media(max-width:900px){.brief-grid{grid-template-columns:1fr}}
.brief-card{background:var(--bg-panel);border:1px solid var(--panel-border);border-radius:16px;padding:24px 22px;display:flex;flex-direction:column;gap:14px}
.brief-card.priority{border-color:rgba(159,134,184,0.3);background:linear-gradient(160deg,rgba(159,134,184,0.05),transparent 60%)}
.brief-top{display:flex;align-items:center;justify-content:space-between}
.brief-num{font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--accent)}
.brief-hook{font-family:var(--serif);font-style:italic;font-size:18px;font-weight:700;line-height:1.35;color:var(--text)}
.brief-tags{display:flex;flex-wrap:wrap;gap:6px}
.brief-tag{font-size:11px;color:var(--text-dim);background:var(--bg-panel-2);border:1px solid var(--panel-border);border-radius:6px;padding:4px 10px}
.brief-goal{font-size:12px;color:var(--text-dim);line-height:1.5;border-top:1px solid rgba(255,255,255,0.07);padding-top:12px;margin-top:auto}
.brief-goal b{color:var(--text)}
.tl-row{display:flex;flex-direction:column;padding-left:22px;position:relative;margin-top:20px}
.tl-row::before{content:'';position:absolute;left:5px;top:8px;bottom:8px;width:2px;background:linear-gradient(to bottom,var(--accent),rgba(159,134,184,0.1))}
.tl-item{position:relative;padding:0 0 18px 18px}
.tl-dot{position:absolute;left:-18px;top:4px;width:10px;height:10px;border-radius:50%;background:var(--accent);box-shadow:0 0 8px var(--accent-glow)}
.tl-dot.dim{background:rgba(255,255,255,0.2);box-shadow:none}
.tl-date{font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--accent);margin-bottom:2px}
.tl-date.dim{color:var(--text-dim)}
.tl-label{font-size:14px;font-weight:700}
.tl-note{font-size:12.5px;color:var(--text-dim);line-height:1.45;margin-top:1px}
.footer-tag{position:absolute;bottom:22px;left:80px;right:80px;display:flex;justify-content:space-between;color:var(--text-dim);font-size:11px;letter-spacing:0.5px;z-index:1}
@media(max-width:640px){.footer-tag{left:20px;right:20px}}
/* index landing */
.idx-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-top:26px}
.idx-card{display:block;text-decoration:none;color:inherit;background:var(--bg-panel);border:1px solid var(--panel-border);border-radius:18px;padding:24px;transition:border-color .2s,transform .15s}
.idx-card:hover{border-color:var(--accent);transform:translateY(-2px)}
.idx-head{display:flex;align-items:center;gap:12px;margin-bottom:16px}
.idx-av{width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#6B5486);display:flex;align-items:center;justify-content:center;font-weight:800;color:#1A1222;flex-shrink:0}
.idx-name{font-size:16px;font-weight:700}
.idx-role{font-size:11.5px;color:var(--text-dim);margin-top:1px}
.idx-metrics{display:flex;gap:18px;border-top:1px solid rgba(255,255,255,0.07);padding-top:14px}
.idx-m .l{font-size:9.5px;text-transform:uppercase;letter-spacing:0.7px;color:var(--text-dim)}
.idx-m .v{font-size:17px;font-weight:800;margin-top:2px;font-variant-numeric:tabular-nums}
.idx-go{margin-top:14px;font-size:12.5px;font-weight:700;color:var(--accent)}
"""

def footer(label, upd):
    return '<div class="footer-tag"><span>'+e(label)+'</span><span>'+e(upd)+'</span></div>'

def ad_card(a):
    return (
        '<div class="vid-card '+e(a["statusClass"])+'">'
        '<div class="vid-thumb">'
        '<div class="vid-code">'+e(a["code"])+'</div>'
        '<div class="vid-status-badge"><span class="pill pill-'+e(a["statusClass"])+'">'+e(a["statusEmoji"])+' '+e(a["statusLabel"])+'</span></div>'
        '<video muted loop playsinline preload="metadata" poster="'+CDN+e(a["poster"])+'" src="'+CDN+e(a["video"])+'"></video>'
        '<button class="vid-sound" type="button" onclick="var v=this.previousElementSibling;v.muted=!v.muted;v.play();this.textContent=v.muted?\'Sound on\':\'Sound off\'">Sound on</button>'
        '<div class="vid-hook-overlay">“'+e(a["hook"])+'”</div>'
        '</div>'
        '<div class="vid-body">'
        '<div class="vid-angle">'+e(a["angle"])+'</div>'
        '<div class="vid-metrics">'
        '<div class="vid-metric"><div class="vm-label">Conversion value</div><div class="vm-value up">'+e(a["gmv"])+'</div></div>'
        '<div class="vid-metric"><div class="vm-label">Your earnings</div><div class="vm-value" style="color:var(--accent)">'+comm(a["gmv"])+'</div></div>'
        '<div class="vid-metric"><div class="vm-label">ROAS</div><div class="vm-value">'+e(a["roas"])+'</div></div>'
        '<div class="vid-metric"><div class="vm-label">Orders</div><div class="vm-value">'+e(a["orders"])+'</div></div>'
        '</div>'
        '<div class="vid-metrics">'
        '<div class="vid-metric"><div class="vm-label">Hook rate</div><div class="vm-value up">'+e(a["hookRate"])+'</div>'+('<div class="vm-note">vs '+e(BENCH["hook"])+' avg</div>' if BENCH["hook"] else '')+'</div>'
        '<div class="vid-metric"><div class="vm-label">CTR</div><div class="vm-value">'+e(a["ctr"])+'</div>'+('<div class="vm-note">vs '+e(BENCH["ctr"])+' avg</div>' if BENCH["ctr"] else '')+'</div>'
        '<div class="vid-metric"><div class="vm-label">Hold 15s</div><div class="vm-value">'+e(a["hold"])+'</div></div>'
        '</div></div></div>'
    )

def report_html(c, meta, prev):
    upd = meta["updated"]
    st = c["status"]
    prev = prev or {}
    # cover
    cover = (
        '<section><div class="glow" style="bottom:-300px;left:-220px;width:1100px;height:1100px;opacity:0.5"></div>'
        '<div class="logo-bar"><div class="logo-dot"></div><span class="logo-text">'+e(meta["brand"])+' · Creator Report</span></div>'
        '<div class="read-badge">\U0001f512 Private · your personal report</div>'
        '<div class="creator-badge"><div class="creator-avatar">'+e(c["initials"])+'</div>'
        '<div><div class="creator-name">'+e(c["name"])+'</div><div class="creator-role">'+e(c["role"])+'</div></div></div>'
        '<h1>Your work,<br><span class="serif">and what’s next.</span></h1>'
        '<div class="subtitle">What your content is doing right now, why it works, and what to film next.</div>'
        '<div class="metric-row">'
        '<div class="metric-chip hero"><div class="mc-label">Your status</div><div class="mc-value" style="color:var(--accent)">'+e(st["emoji"])+' '+e(st["label"])+'</div><div class="mc-note">'+e(st["note"])+'</div></div>'
        '<div class="metric-chip"><div class="mc-label">Conversion value</div><div class="mc-value up">'+e(c["totals"]["gmv"])+'</div><div class="mc-note">'+(delta(c["totals"]["gmv"], prev.get("gmv")) or "Sales your videos drove")+'</div></div>'
        '<div class="metric-chip hero"><div class="mc-label">Your earnings · 10%</div><div class="mc-value" style="color:var(--accent)">'+comm(c["totals"]["gmv"])+'</div><div class="mc-note">Simulated · live with Trybe</div></div>'
        '<div class="metric-chip"><div class="mc-label">ROAS</div><div class="mc-value">'+e(c["totals"]["roas"])+'</div><div class="mc-note">Return on ad spend</div></div>'
        '<div class="metric-chip"><div class="mc-label">Ad spend</div><div class="mc-value">'+e(c["totals"]["adspend"])+'</div><div class="mc-note">Behind your content</div></div>'
        '<div class="metric-chip"><div class="mc-label">Orders</div><div class="mc-value">'+e(c["totals"]["orders"])+'</div><div class="mc-note">'+e(c["totals"]["impressions"])+' impressions</div></div>'
        '</div>'
        '<div class="meta-row">'
        '<div class="meta-item"><div class="meta-label">Report</div><div class="meta-value">'+e(upd)+'</div></div>'
        '<div class="meta-item"><div class="meta-label">Product</div><div class="meta-value">'+e(c["product"])+'</div></div>'
        '<div class="meta-item"><div class="meta-label">Angle</div><div class="meta-value">'+e(meta["angle"])+'</div></div>'
        '</div>'+footer("CREATOR REPORT · "+c["name"].upper(), upd)+'</section>'
    )
    # ads
    ads = (
        '<section><div class="glow" style="top:-260px;right:-200px;width:960px;height:960px;opacity:0.45"></div>'
        '<div class="sec-head"><span class="sec-num">01</span><h2>Your videos</h2></div>'
        '<div class="subtitle">Every creative of yours we’re running, the sales it drove and your earnings. <b>Earnings are simulated at 10%</b> — they go live once Trybe is set up.</div>'
        '<div class="vid-grid">'+''.join(ad_card(a) for a in c["ads"])+'</div>'
        '<div class="callout">'+e(c["callout"])+'</div>'
        +footer("CREATOR REPORT · 01", upd)+'</section>'
    )
    # formula
    steps = c["formula"]
    fsteps = ''.join(
        '<div class="fstep"><div class="fstep-top"><span class="fstep-time">'+e(s["time"])+'</span><span class="fstep-no">'+str(i+1)+'</span></div>'
        '<div class="fstep-label">'+e(s["label"])+'</div><div class="fstep-quote">“'+e(s["quote"])+'”</div></div>'
        for i,s in enumerate(steps))
    formula = (
        '<section><div class="glow" style="bottom:-200px;left:-160px;width:900px;height:900px;opacity:0.4"></div>'
        '<div class="sec-head"><span class="sec-num">02</span><h2>Why it works</h2></div>'
        '<div class="subtitle">The structure behind your winner — the skeleton to keep using.</div>'
        '<div class="formula-strip" style="--n:'+str(len(steps))+'">'+fsteps+'</div>'
        '<div class="callout">'+e(c["formulaNote"])+'</div>'
        +footer("CREATOR REPORT · 02", upd)+'</section>'
    )
    # keep / push
    keep = ''.join('<li><span class="ki-item">'+e(k["item"])+'</span><span class="ki-why">'+e(k["why"])+'</span></li>' for k in c["keep"])
    push = ''.join('<li><span class="ki-item">'+e(p["item"])+'</span><span class="ki-why">'+e(p["why"])+'</span></li>' for p in c["push"])
    kp = (
        '<section><div class="glow" style="top:-220px;right:-180px;width:900px;height:900px;opacity:0.4"></div>'
        '<div class="sec-head"><span class="sec-num">03</span><h2>Keep doing / push further</h2></div>'
        '<div class="subtitle">What’s working, and where the next gain is.</div>'
        '<div class="ki-grid">'
        '<div class="ki-card keep"><div class="ki-title"><span class="dot">✅</span> Keep doing</div><ul class="ki-list">'+keep+'</ul></div>'
        '<div class="ki-card push"><div class="ki-title"><span class="dot">\U0001f527</span> Push further</div><ul class="ki-list">'+push+'</ul></div>'
        '</div>'+footer("CREATOR REPORT · 03", upd)+'</section>'
    )
    # briefs
    bcards = ''
    for b in c["briefs"]:
        tag = '<span class="pill pill-scale">'+e(b["tag"])+'</span>' if b.get("tag") else ''
        cls = ' priority' if b.get("tag") else ''
        tags = ''.join('<span class="brief-tag">'+e(t)+'</span>' for t in b["tags"])
        bcards += ('<div class="brief-card'+cls+'"><div class="brief-top"><span class="brief-num">'+e(b["num"])+'</span>'+tag+'</div>'
                   '<div class="brief-hook">“'+e(b["hook"])+'”</div>'
                   '<div class="brief-tags">'+tags+'</div>'
                   '<div class="brief-goal"><b>Why:</b> '+e(b["why"])+'</div></div>')
    briefs = (
        '<section><div class="glow" style="bottom:-220px;left:-160px;width:900px;height:900px;opacity:0.42"></div>'
        '<div class="sec-head"><span class="sec-num">04</span><h2>Film these next</h2></div>'
        '<div class="subtitle">Three briefs built from what’s working for you. Start with #1.</div>'
        '<div class="brief-grid">'+bcards+'</div>'
        '<div class="cta-block"><div><div class="cta-t">Your next brief is ready</div>'
        '<div class="cta-s">Pick one above, film it your way, and send us your raw footage — we handle the rest.</div></div>'
        '<div class="cta-btn">Shoot by '+e(meta["shootBy"])+'</div></div>'
        +footer("CREATOR REPORT · 04", upd)+'</section>'
    )
    # timeline (generic)
    tl = (
        '<section><div class="glow" style="top:-200px;right:-160px;width:860px;height:860px;opacity:0.4"></div>'
        '<div class="sec-head"><span class="sec-num">05</span><h2>What happens next</h2></div>'
        '<div class="subtitle">From shoot to live — you’re always in the loop before anything runs.</div>'
        '<div class="tl-row">'
        '<div class="tl-item"><div class="tl-dot"></div><div class="tl-date">This week</div><div class="tl-label">Brief received</div><div class="tl-note">Questions before you shoot? Reply any time.</div></div>'
        '<div class="tl-item"><div class="tl-dot"></div><div class="tl-date">+3 days</div><div class="tl-label">Raw footage → Drive</div><div class="tl-note">2–3 takes per video. No editing needed — we handle it.</div></div>'
        '<div class="tl-item"><div class="tl-dot dim"></div><div class="tl-date dim">+5 days</div><div class="tl-label">Edited cuts for your review</div><div class="tl-note">See the finished edits before they go live.</div></div>'
        '<div class="tl-item"><div class="tl-dot dim"></div><div class="tl-date dim">+1 week</div><div class="tl-label">Live & into testing</div><div class="tl-note">Tracked against your current winners.</div></div>'
        '<div class="tl-item"><div class="tl-dot dim"></div><div class="tl-date dim">Next Monday</div><div class="tl-label">This report updates</div><div class="tl-note">Fresh numbers and a new brief, every week.</div></div>'
        '</div>'
        '<div class="callout"><b>Keep going.</b> Your content is one of the signals carrying the account. This report refreshes every week so you always know what’s working.</div>'
        +footer("CREATOR REPORT · 05", upd)+'</section>'
    )
    body = cover+ads+formula+kp+briefs+tl
    return ('<meta charset="utf-8">'
            '<title>'+e(c["name"])+' · 8HOURS Report</title>'
            '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            '<style>'+CSS+'</style>'+body)

def overview_html(data, links):
    """Internal overview for the team (lists all creators). Served at an unguessable path, not from root."""
    cards = ''
    for c, folder in links:
        st = c["status"]
        cards += ('<a class="idx-card" href="../'+e(folder)+'/">'
                  '<div class="idx-head"><div class="idx-av">'+e(c["initials"])+'</div>'
                  '<div><div class="idx-name">'+e(c["name"])+'</div><div class="idx-role">'+e(c["product"])+'</div></div></div>'
                  '<div style="margin-bottom:14px"><span class="pill pill-'+e(st["class"])+'">'+e(st["emoji"])+' '+e(st["label"])+'</span></div>'
                  '<div class="idx-metrics">'
                  '<div class="idx-m"><div class="l">Conversion value</div><div class="v up">'+e(c["totals"]["gmv"])+'</div></div>'
                  '<div class="idx-m"><div class="l">Earnings 10%</div><div class="v" style="color:var(--accent)">'+comm(c["totals"]["gmv"])+'</div></div>'
                  '<div class="idx-m"><div class="l">ROAS</div><div class="v">'+e(c["totals"]["roas"])+'</div></div>'
                  '</div><div class="idx-go">Open report →</div></a>')
    return ('<meta charset="utf-8">'
            '<title>8HOURS · Creator Reports (team)</title>'
            '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            '<meta name="robots" content="noindex, nofollow">'
            '<style>'+CSS+'</style>'
            '<section><div class="glow" style="bottom:-300px;left:-220px;width:1100px;height:1100px;opacity:0.5"></div>'
            '<div class="logo-bar"><div class="logo-dot"></div><span class="logo-text">'+e(data["brand"])+' · Creator Reports · Team</span></div>'
            '<h1>Creator<br><span class="serif">Reports.</span></h1>'
            '<div class="subtitle">Internal overview — all top '+e(data["brand"])+' creators. '+e(data["updated"])+'. Each creator gets only their own private link.</div>'
            '<div class="idx-grid">'+cards+'</div>'
            '<div class="footer-tag"><span>8HOURS · CREATOR REPORTS · TEAM</span><span>'+e(data["updated"])+'</span></div>'
            '</section>')

def root_html(data):
    """Neutral public root: no creator list, no data. Just points people to their personal link."""
    return ('<meta charset="utf-8">'
            '<title>8HOURS · Creator Reports</title>'
            '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            '<meta name="robots" content="noindex, nofollow">'
            '<style>'+CSS+'</style>'
            '<section style="text-align:center;align-items:center"><div class="glow" style="bottom:-300px;left:-220px;width:1100px;height:1100px;opacity:0.4"></div>'
            '<div class="logo-bar" style="justify-content:center"><div class="logo-dot"></div><span class="logo-text">'+e(data["brand"])+' · Creator Reports</span></div>'
            '<h1 style="max-width:620px">Your report is<br><span class="serif">private.</span></h1>'
            '<div class="subtitle" style="margin-left:auto;margin-right:auto">Open the personal link we sent you to see your videos, results and next brief. If you don’t have it, message your 8HOURS contact.</div>'
            '</section>')

def main():
    global BENCH
    data = json.load(open(DATA, encoding="utf-8"))
    bm = data.get("benchmarks") or {}
    BENCH = {"hook": bm.get("hook", ""), "ctr": bm.get("ctr", "")}
    meta = {"brand": data["brand"], "updated": data["updated"], "angle": data["angle"], "shootBy": data.get("shootBy", "")}

    history = {}
    if os.path.isfile(HISTORY):
        try:
            history = json.load(open(HISTORY, encoding="utf-8"))
        except (ValueError, OSError):
            history = {}

    if os.path.isdir(DIST):
        shutil.rmtree(DIST)
    os.makedirs(DIST)
    open(os.path.join(DIST, "index.html"), "w", encoding="utf-8").write(root_html(data))
    open(os.path.join(DIST, "robots.txt"), "w").write("User-agent: *\nDisallow: /\n")
    open(os.path.join(DIST, "_headers"), "w").write("/*\n  X-Robots-Tag: noindex, nofollow\n")

    links = []
    for c in data["creators"]:
        folder = c["slug"] + "-" + token(c["slug"])
        d = os.path.join(DIST, folder)
        os.makedirs(d)
        prev = history.get(c["slug"]) or {}
        open(os.path.join(d, "index.html"), "w", encoding="utf-8").write(report_html(c, meta, prev))
        links.append((c, folder))

    ov = "overview-" + token("overview")
    os.makedirs(os.path.join(DIST, ov))
    open(os.path.join(DIST, ov, "index.html"), "w", encoding="utf-8").write(overview_html(data, links))

    print("Built", len(links), "private reports + team overview in", DIST)
    print("  TEAM overview:  /" + ov + "/")
    for c, folder in links:
        print("  /" + folder + "/   " + c["name"] + "  [" + c["status"]["label"] + "]")

if __name__ == "__main__":
    main()
