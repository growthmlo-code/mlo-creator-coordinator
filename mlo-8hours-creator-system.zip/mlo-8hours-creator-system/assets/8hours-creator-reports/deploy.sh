#!/bin/bash
# Rebuild the 8HOURS per-creator reports from creators.json and deploy to Cloudflare Pages.
# Usage: bash ~/claude/8hours-creator-reports/deploy.sh
set -e
cd "$HOME/claude/8hours-creator-reports"
python3 build_reports.py
npx wrangler pages deploy dist \
  --project-name=8hours-creator-reports --branch=main --commit-dirty=true
