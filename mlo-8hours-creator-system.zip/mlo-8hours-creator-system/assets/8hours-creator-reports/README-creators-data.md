# creators.json (datos reales) — EXCLUIDO del paquete

El `creators.json` real de 8HOURS contiene **nombres de creadores + métricas de negocio reales** (GMV, ad spend, ROAS, orders) y la comisión simulada. **No se incluye** en este paquete por privacidad (va a GitHub).

Para reconstruirlo: usa `creators.example.json` como plantilla y rellena con datos reales de Atria (ver el skill `mlo-creator-report`). El real vive solo en local: `~/claude/8hours-creator-reports/creators.json`.
