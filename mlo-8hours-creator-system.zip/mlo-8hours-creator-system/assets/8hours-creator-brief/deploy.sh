#!/bin/bash
# Rebuild the 8HOURS creator brief from brief.json and redeploy to Cloudflare Pages.
# Usage: bash ~/claude/8hours-creator-brief/deploy.sh
set -e
DIR="$HOME/claude/8hours-creator-brief"
SKILL="$HOME/.claude/skills/creator-brief"
cd "$DIR"

# 1. Rebuild the static deck from brief.json (validates, regenerates content.js)
python3 "$SKILL/scripts/build_brief.py" brief.json

# 1b. Swap in the 8HOURS-branded renderer (PDF look & feel: serif display + lavender gradient).
#     The build uses the skill's default renderer; this overrides it with our brand restyle.
cp "$DIR/renderer-8hours.html" "$DIR/creator-brief-8hours/index.html"

# 2. Deploy to Cloudflare Pages (production branch main -> https://8hours-creator-brief.pages.dev)
npx wrangler pages deploy creator-brief-8hours \
  --project-name=8hours-creator-brief --branch=main --commit-dirty=true
