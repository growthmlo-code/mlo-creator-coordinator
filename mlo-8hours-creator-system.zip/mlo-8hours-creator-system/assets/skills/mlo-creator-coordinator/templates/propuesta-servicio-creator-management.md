# Propuesta de servicio · Creator Management (Módulo 15, pitch a cliente)

## Qué vende MLO
Un **motor de contenido de creador** mensual, integrado con la estrategia creativa y el media buying de la marca: sourcing + vetting + negociación + contratos + coordinación de producto + briefs + producción + edición + whitelisting + performance. El cliente pone el producto y aprueba; MLO opera.

## Estructura del pack (adaptar por marca)
- **Setup (mes 1):** kickoff con estrategia, canal `#creator-ads-[marca]`, prelista de perfiles validada, contratos, primeros [2-3] creadores.
- **Recurrente (mensual):** [2-3] creadores × [2] vídeos × [2-3] hooks = [8-18] piezas/mes listas para ads; edición en Editors Hub; whitelisting activado; reporte de spend/winners por creador (skill `mlo-creator-spend-report` + dashboards Atria).
- **Costes de creadores:** aparte, transparentes (packs + premium whitelisting); el cliente envía el producto.
- **Fee MLO:** [fijo mensual] o [fijo + variable por winners/adspend] (ver Growth Partner Agreement como molde).

## Por qué (argumentos)
- El creativo es la palanca #1 en Meta 2026; el UGC natural es la mayor fuente de winners.
- Whitelisting (partnership/Spark ads) sube el rendimiento vs ad de marca; sin sistema, los rights se pierden.
- Sistema > improvisación: canal único, Roster, Pipeline de Colaboraciones visible en el portal del cliente, SLAs <24h.

## KPIs que se comprometen
Piezas entregadas/mes · % con rights vigentes · coste por pieza · **coste por winner** · hit rate de creador · spend por creador y ROAS (Atria/Meta).
