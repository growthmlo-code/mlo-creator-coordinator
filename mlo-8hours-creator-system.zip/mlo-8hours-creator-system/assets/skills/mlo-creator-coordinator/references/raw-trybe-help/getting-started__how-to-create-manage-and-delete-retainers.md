# /help/getting-started/how-to-create-manage-and-delete-retainers
Fuente: https://jointrybe.com/help/getting-started/how-to-create-manage-and-delete-retainers (capturado 18-sep-2026)

How to Create, Manage, & Delete Retainers

Learn how to create, edit, and manage retainer programs to guarantee your creators a baseline payout for their work.

Add a Retainer
Go to Creators → Programs — Head to the Creators tab, then click Programs.
Select a Program — Choose the program you want to manage.
Add Retainer — Click the three dots next to the creator's name and select Add Retainer.
Choose a Retainer Type
Standard Retainer

A simple, fixed arrangement — set a number of approved creatives for a fixed payout.

Example: 10 approved creatives for $1,000.

Smart Retainer

Tied to a commission program, a smart retainer acts as a guaranteed minimum. You guarantee the creator a minimum amount if they hit the required number of creatives:

If their commission earnings are lower than the guarantee, you cover the difference.
If their commission earnings exceed the guarantee, you don't pay anything extra.

Example: You guarantee $3,000 for 30 creatives.

Creator earns $2,000 in commission → you pay an additional $1,000 to reach $3,000.
Creator earns $3,500 in commission → you pay nothing extra.
Configure the Retainer

After selecting the retainer type:

Set the Number of Creatives — Enter how many creatives the creator needs to complete.
Choose Creative Type — Select whether the goal counts videos only, photos only, or both.
Choose the Goal Type — Select whether the goal is based on all submitted creatives or approved creatives only.

We recommend approved creatives only — so lower quality submissions don't count toward the requirement.

Set the Payout Amount — Enter the total payout for the retainer.
Choose Frequency — Select one-time or recurring. Recurring retainers automatically renew, while one-time retainers give you more flexibility.

We recommend starting with a one-time retainer and re-evaluating each month so you can adjust based on performance.

Set the Date Range — Choose a start and end date. This defines the window in which the creator needs to complete the required creatives.
Save — Click the check mark to add the creator to the retainer.
Edit a Retainer

Click the three dots next to the creator's name and update the retainer as needed.

Make sure any changes line up with what you've agreed on with the creator. Unexpected changes can damage the relationship and reduce output.

Remove a Retainer

Click the three dots next to the creator's name and select Remove Retainer.

Need Help?

If you have questions about structuring your retainer programs, click the "?" icon in the top-right of your Trybe dashboard.
