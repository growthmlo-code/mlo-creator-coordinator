# /help/getting-started/how-to-import-products-and-manage-sample-requests
Fuente: https://jointrybe.com/help/getting-started/how-to-import-products-and-manage-sample-requests (capturado 18-sep-2026)

How to Import Products & Manage Sample Requests

Learn how to import your product catalog from Shopify and manage sample requests from creators.

Import Products from Shopify
Go to Settings — Navigate to Settings, then click Product Catalog.
Import Products — Click Import from Shopify, select the product(s) you'd like to bring into Trybe, then click Save.
Enable Sample Requests
Go to Settings → Product Catalog — Navigate to Settings, then click Product Catalog.
Turn on Allow Sample Requests — At the top of the Product Catalog, switch Allow Sample Requests on. This is the master switch for your whole brand — while it's off, creators can't request samples of any product. You'll still choose exactly which products allow samples per program in the next step.

The old separate "Sample Requests" settings tab has moved — this toggle now lives at the top of your Product Catalog.

Add Products to a Program & Set Their Controls

Product controls are now set per product, per program, so the same product can behave differently in different programs. You can manage them in either place:

From the Product Catalog:

Open a product's Programs menu — In Settings → Product Catalog, click Programs on the product row.
Assign it to a program — Toggle on each program you want the product in.
Set its controls — For each program, set:
Active — the product appears in that program's submission picker.
Sample — creators in that program can request it as a sample (requires the brand-wide Allow Sample Requests switch to be on).
Encourage — highlight the product to creators in that program.

From the program editor:

Go to Creators → Programs — Head to the Creators tab, then click Programs.
Select a Program, then Manage Products — add the products you imported and set Active / Sample / Encourage (and, per product, which Variants are sample-eligible).
Save.

This step is important — a program with no assigned products is invisible to its creators: they can't submit content or request samples until you assign products.

Review Sample Requests
Go to the Samples Tab — Head to the Samples tab to view all incoming sample requests.
Approve or Reject — Review each request and approve or reject it.

If a creator has requested multiple products and you only want to approve certain ones, you can uncheck specific products before approving the request.

Need Help?

If you have questions about managing your product catalog or sample requests, click the "?" icon in the top-right of your Trybe dashboard.
