# /help/brand-guides/finding-and-onboarding-creators
Fuente: https://jointrybe.com/help/brand-guides/finding-and-onboarding-creators (capturado 18-sep-2026)

How to Find & Onboard Creators

This guide walks you through a proven approach to sourcing creators, setting up your commission structure, and scaling your program with smart retainers.

This playbook is based on what we've seen work consistently across brands. Feel free to adapt it to fit your niche, offer, and creative style.

Setting Up Your Commission Structure

Before you start inviting creators, establish a baseline commission structure that works for both your unit economics and creator motivation.

We recommend a % of GMV commission structure. This ensures you only pay when a creative performs, and creators are incentivized to make high-performing content.

Goals for Your Starting Commission

Your initial commission should:

Lower friction — Make it easy for creators to get started
Feel fair — Give everyone a reasonable starting point
Leave room to grow — Create space to reward top performers later

This doesn't need to be perfect on day one. Think of it as your default creator tier that you'll optimize over time.

Two Ways to Find Creators

With your commission structure in place, start sourcing. You have two channels, and the strongest programs run both:

Channel How it works Best for
Trybe Discovery Creators already on Trybe — you invite them, or they find you and request to join Volume, speed, and creators who already know the workflow
TikTok Shop You source creators manually off-platform and invite them in Reaching proven product-video creators who aren't on Trybe yet

Discovery is faster because those creators are already set up to submit. TikTok Shop is where you go to widen the pool beyond it. Start with Discovery, then supplement.

Channel 1: Trybe Discovery

Open the Discovery tab in your dashboard. It has four sub-tabs — Discovery, Inbox, Invited, and Messages — covering both directions.

Get found (inbound)

Creators browse listed brands and request to join, so this runs without you doing anything each week.

Go to Creators → Programs
Make 1–2 of your creator programs discoverable

Your brand then appears in the creator-facing discovery feed. Join requests land in your Inbox.

Requests expire after 30 days

Pending join requests expire on a 30-day clock, and your Inbox is sorted oldest-first so the ones closest to expiring sit at the top. You'll see a banner when requests are within a week of expiring. An expired request isn't lost — either side can re-request, which resets the clock — but you've lost the momentum.

A program with no discovery listing is invisible to creators browsing the feed. If you're wondering why no one is applying, check this first.

Go find them (outbound)

On the Discovery sub-tab, browse and filter the creator pool:

Filter by country, gender, and your Favorites shortlist
Sort by performance, newest, or oldest
Click any creator to open their full profile, then invite them from there
Favorite creators as you browse to build a shortlist before you commit invites

Invites you've sent appear under Invited, and any conversation with a creator before they join lives in Messages.

Invites are rate-limited by daily credits

You get a set number of invite credits per day. If you bulk-invite more creators than you have credits for, the extras are skipped — not queued — and you'll see exactly how many were dropped. Shortlist with Favorites first so you spend the day's credits on the creators you actually want.

You can set a program to require join approval or let creators in automatically. Requiring approval gives you a gate; auto-join gets creators submitting faster. Pick based on how much you want to curate.

Channel 2: Finding Creators on TikTok Shop

Discovery only reaches creators already on Trybe. To widen the pool, go directly to TikTok Shop and identify creators that match your brand's vibe, demographic, and content style.

What to Look For

When evaluating potential creators, prioritize those who:

Already make product-style videos — They understand how to showcase products naturally
Feel authentic on camera — Not overly scripted or salesy
Match your customer profile — Their audience aligns with your target demographic
Post consistently — They have an established content rhythm
Outreach Template

Once you find a creator, send a short, direct message:

"Hey! Just saw your TikTok Shop video. We'd love to get you on Trybe — the platform we use to run Meta ads. You're already doing 99% of the work. You'd just upload your videos to Trybe and get paid 2–3x more when your content is used in ads.

We're only bringing on a couple of creators we think will absolutely crush it. Happy to send details if you're interested."

You can either send the invite link after they reply, or include it directly in your first message. Both approaches work — choose what feels most natural for your brand.

Repeat this process until you've built enough inbound interest, then send interested creators an invite link to sign up.

Where to get the invite link

Go to Creators → Programs, then click Invite Link on the program you want them to join. Anyone who signs up through that link lands directly in that program.

Which Channel to Lean On
Just getting started? List your programs in Discovery first — it's the only channel that brings creators to you while you're doing something else.
Need volume fast? Invite outbound through Discovery. Those creators are already onboarded, so they can submit the same week.
Hit a ceiling in Discovery, or chasing a specific niche? That's what TikTok Shop sourcing is for.
Running a mature program? Keep Discovery listings live permanently for inbound, spend your daily invite credits on the shortlist, and source on TikTok Shop for the creators you can't find any other way.
Understanding Smart Retainers

A Smart Retainer is a performance-based retainer that works alongside your commission program — not as a replacement.

How Smart Retainers Work

Instead of replacing commission, smart retainers:

Set a guaranteed earning floor — Creators know their minimum payout
Reward overperformance — Commission still applies on top
Align incentives — Tied to approved deliverables, not just time

Think of it as a commission floor, not a bonus.

Smart Retainer Example

Here's how it works in practice:

Component Value
Smart Retainer $2,000
Requirement 30 approved videos
Commission Earned as normal

Payout scenarios:

Creator earns $1,500 in commission after submitting 30 approved videos → They receive an additional $500 to reach the $2,000 guarantee

Creator earns $2,000+ in commission → No additional retainer payout needed (they've already exceeded the floor)

Creator doesn't hit 30 approved videos → The retainer does not fully pay out

This structure creates a guaranteed minimum for creators with no downside for brands — plus a strong incentive to both perform and deliver volume.

Identifying Top Performers

Once you have creators actively making content, review performance based on what matters most to your brand.

Key Performance Indicators

Consider metrics like:

CTR (Click-Through Rate) — How engaging is the content?
Hook strength — Do viewers stick around past the first 3 seconds?
Conversions — Is the content driving sales?
Consistency — Do they deliver reliably?
Introducing Retainers to Top Creators

From your performance review:

Select the top X% of creators
Invite them into a smart retainer program

This helps you:

Lock in your best creators — Reduce risk of losing top talent
Increase content velocity — Guaranteed output from proven performers
Reduce sourcing overhead — Spend less time constantly finding new creators
Continuously Optimizing Your Program

From here, it becomes an ongoing optimization loop.

Levers You Can Adjust
Retainer amounts — Increase payouts for top performers
Video requirements — Raise or lower deliverable thresholds
Commission percentages — Adjust based on performance tiers
Creator rotation — Move creators in and out of retainers based on results

There's no single correct setup. The best program is one that keeps creators motivated, improves content quality over time, and lowers your cost of acquisition.

Adjust based on what you see working, and don't be afraid to experiment.

Need Help?

If you have questions about setting up your creator program:

Use the chat bubble in the bottom-right corner of this page
Click the "?" icon in the top-right of your Trybe dashboard
