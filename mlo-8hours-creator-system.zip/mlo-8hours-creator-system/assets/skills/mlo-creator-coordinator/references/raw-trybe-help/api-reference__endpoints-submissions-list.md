# /help/api-reference/endpoints-submissions-list
Fuente: https://jointrybe.com/help/api-reference/endpoints-submissions-list (capturado 18-sep-2026)

Endpoints — List submissions
List submissions
GET /v1/submissions

Returns your brand's submissions, newest first, cursor-paginated. Only the four review states ever appear — submissions still being processed (pre-review) and submissions that were superseded by an approved revision are never returned. Submissions that are still in partner review (and not yet partner-approved) are also invisible.

Query
Param Type Default Notes
status enum — Filter by review status: pending, approved, rejected, revision_requested. Optional.
creator_id string — Filter to one creator (creator_<uuid>). Optional.
group_id string — Filter to one submission group's variants (subgroup_<uuid>). Optional.
angle string — Filter to submissions tagged with this angle, by name — matched case-insensitively against the angles[].name values the response shows (the same set as the brand portal). Optional.
program_id string — Filter to submissions pinned to this program (creator_program_<uuid>, as shown in program.id). Optional.
product_id string — Filter to submissions tagged with this product (product_<uuid>, as shown in products[].id). Optional.
transcript_language string — Filter to videos whose completed transcript is in this language — the ISO 639-1 code shown in transcript.language (en, es, …). Images and videos with no transcript yet never match. Optional.
query string — Filter to submissions whose video says or shows these words: a case-insensitive substring match against the completed transcript, the on-screen text and the creator's note. One phrase of 2–100 characters; % and _ match literally, no wildcards. Not semantic — lawyer finds "lawyers" and "former lawyer", never "attorney". Images and untranscribed videos match only on the note. Optional.
limit integer 20 Max 100.
after string — Opaque cursor (forward). Pass the response's next_cursor back here.
before string — Opaque cursor (backward). Mutually exclusive with after.

Results are ordered by created_at DESC, id DESC for consistent cursor pagination.

Response
{
"object": "list",
"data": [
{
"object": "submission",
"id": "submission_8f3e21a0-...",
"creator": {
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe"
},
"status": "pending",
"media_type": "video",
"version": 2,
"revision_of": null,
"program": { "id": "creator_program_a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d", "name": "Spring UGC" },
"ads": { "count": 3, "first_day": "2026-08-30", "last_day": "2026-09-05" },
"thumbnail_url": "https://cdn.jointrybe.com/brands/<brand>/submissions/<id>/thumbnail.jpg",
"group": {
"id": "subgroup_8f3e21a0-...",
"name": "Summer hooks",
"description": "Same concept, different hooks"
},
"products": [
{ "id": "product_8f3e21a0-...", "name": "Glow Serum" }
],
"creator_comment": "Filmed outdoors in natural light",
"review_comment": null,
"transcript": { "language": "en", "text": "..." },
"angles": [
{ "name": "Unboxing & First Impressions", "source": "manual", "confidence": null },
{ "name": "GRWM", "source": "ai", "confidence": 0.82 }
],
"asset": {
"url": "https://<account>.r2.cloudflarestorage.com/.../clip.mp4?X-Amz-Expires=1200&X-Amz-Signature=...",
"expires_at": "2026-05-01T12:20:00Z"
},
"created_at": "2026-05-01T12:00:00Z"
}
],
"has_more": true,
"next_cursor": "eyJjcmVhdGVkX2F0Ijo...",
"previous_cursor": null
}

Fields
status — one of pending, approved, rejected, revision_requested. These map from Trybe's internal states (PENDING, APPROVED, DENIED, REVISION_REQUESTED). Pre-review states and superseded never appear.
media_type — video or image.
version — the revision number. Each revision is its own submission with its own id; you review whichever version is currently pending.
group — the submission group (a set of variants on one concept), with name and description as the creator provided them, or null if the submission isn't grouped.
products — the products tagged on the submission, in the creator's order, each { id, name }. May be empty.
creator_comment — the note the creator attached when submitting, or null.
trybe_id — the Trybe ID: the last 8 characters of the submission uuid, as shown in the portal. Every ad you build from this content — in Trybe's ads builder, Meta Ads Manager, or anywhere else — must carry trybe=<trybe_id> as a query parameter on the destination URL and at the end of the ad name. That tag is how Trybe attributes the ad's sales to the creator and pays them; an untagged ad is invisible to attribution.
revision_of — the submission this one revises (its previous version), or null for a first version. Lists return only the latest version of each chain; an older version stays readable by id.
program — { id, name } of the program the submission was pinned to at upload, or null for legacy rows.
ads — { count, first_day, last_day }: all-time usage of this content in ads across platforms (distinct ads with delivery; UTC days). count: 0 means it has never run as an ad. This is usage, not performance.
review_comment — your brand's most recent review feedback on this submission, or null if it hasn't been reviewed yet.
transcript — { language, text } for videos with a completed transcript, or null (images, or no valid transcript yet). language is an ISO code (e.g. en) and may be null.
angles — 0–3 content angles, the same set shown in the brand portal. Each is { name, source, confidence }:
source — manual (you tagged it) or ai (auto-matched).
confidence — a 0–1 score for ai angles; null for manual.
name — the angle's current name, or the name it was classified against if the angle was since deleted.
thumbnail_url — a public, cacheable image URL of the submission's poster frame, or null for the rare submission without one. Unlike asset.url it is not presigned and does not expire, so it is safe to show in a dashboard or store.
asset — a short-lived download URL for the submission's media, { url, expires_at }, or null when no downloadable asset is available. url is a presigned link that expires ~20 minutes after the response (expires_at is the ISO 8601 instant it stops working). Download it promptly and re-request the submission to get a fresh URL rather than storing it — saved URLs stop working, so don't cache them in your database or dashboards. It's a fetch handle for the media, not a permanent or shareable address.
Errors
Status Type
400 validation_error — bad filter value, unknown parameter, invalid cursor, or both after and before
401 invalid_api_key
403 feature_not_enabled — this endpoint isn't enabled for your brand
429 rate_limit_exceeded
