# /help/api-reference/getting-started
Fuente: https://jointrybe.com/help/api-reference/getting-started (capturado 18-sep-2026)

Getting Started

The Trybe Brand API is a read-only HTTP API that lets you pull data about your creators and creator performance into your own BI tools, dashboards, or internal systems.

This is not a public API. Access is gated per-brand and authenticated via API key. All endpoints return only data that belongs to the brand the key was issued for.

Base URL
https://api.jointrybe.com/v1

All endpoints are versioned with v1. Within v1 we will only make additive changes (new endpoints, new optional fields). Breaking changes ship as a future v2.

Get an API key
In the Trybe brand portal, open the Integrations page.
In the API Access section, click Create API key.
Copy the key shown in the modal — it is only displayed once. Store it in a secrets manager.
Use it as a bearer token on every request:
Authorization: Bearer tk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxx

If you lose the key, return to the same screen and rotate it. Rotation invalidates the previous key immediately.

Your first request
curl -H "Authorization: Bearer tk_live_..." \
https://api.jointrybe.com/v1/creators?limit=2

Response:

{
"object": "list",
"data": [
{
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe",
"joined_at": "2025-08-12T14:23:01Z"
}
],
"has_more": true,
"next_cursor": "eyJqb2luZWRfYXQi...",
"previous_cursor": null
}

What the API exposes
Endpoint Purpose
GET /v1/creators List active creators for your brand
GET /v1/creators/{creator_id} Get a creator with their program enrollments and commission summaries
GET /v1/creator-performance Bulk creator performance over a date range — earnings, conversions, GMV, submissions, ads

See the Endpoints articles in this section for full request/response shapes. The set of endpoints available to you depends on what's enabled for your brand.

Need something else?

If you'd like to request additional functionality or endpoints, contact your Trybe account manager — these may be added in future API versions.
