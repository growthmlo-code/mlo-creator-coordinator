# /help/getting-started/how-to-move-creators-to-different-commission-programs
Fuente: https://jointrybe.com/help/getting-started/how-to-move-creators-to-different-commission-programs (capturado 18-sep-2026)

How to Move Creators to Different Commission Programs

Learn how to transfer a creator from one commission program to another in just a few clicks.

Before You Start

Make sure you have at least two commission programs set up — you'll need both a current program and a new one to move the creator into.

Steps to Transfer a Creator
Go to Creators — Head to the Creators tab in your Trybe dashboard.
Open Commission Programs — Click Commission Programs at the top of the page.
View Creators — Click View Creators on the program the creator is currently in.
Select the Creator — Find the creator you want to transfer. Hover over their row and click the button that appears.
Choose the New Program — Select the commission program you want to move them to, then click Move Creator.

That's it — the transfer is complete.

Moving a Creator into a Partner-Managed Program

Some of your commission programs may be partner-managed — set up and run by a partner organization (an agency or coach) that you've connected with. These programs are tagged with a Partner label in the destination picker.

Moving a creator into a partner-managed program is treated as delegating that creator's management to the partner. When you select a partner program and click Move Creator, you'll see a confirmation screen showing the creator and partner together. Once you confirm:

The partner will earn commission on this creator's future sales, per their commission rules.
The partner becomes this creator's sponsor in your brand.
The creator joins the partner's creator roster (if they aren't already), gaining access to the partner's chat channels.
You won't be able to manage commission rates for this creator unless the partner delegates that back to you.
Past earnings and payouts are not affected — only future activity flows to the new program.

Once a creator is delegated to a partner, they can't be moved back out from the brand side. If you need to reverse the delegation, contact the partner.

Need Help?

If you have questions about managing your commission programs, click the "?" icon in the top-right of your Trybe dashboard.
