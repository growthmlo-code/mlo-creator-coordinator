# /help/brand-guides/using-post-ids-on-meta
Fuente: https://jointrybe.com/help/brand-guides/using-post-ids-on-meta (capturado 18-sep-2026)

How to Use Post IDs on Meta

When you duplicate an ad in Meta, the copy starts from zero — no likes, no comments, no shares. Using a post ID points the new ad at the same underlying post, so all of that social proof carries over.

Why this matters

Social proof compounds. An ad showing 400 comments converts differently to an identical ad showing none — and if you duplicate a proven winner without the post ID, you throw away every bit of engagement it earned.

Step 1: Find the Post ID
In Ads Manager, go to the ad whose engagement you want to keep and click Edit
Click the share button and choose Facebook post with comments
The live post opens in a new tab
Look at the end of the URL — you want the clean string of numbers immediately after posts
Copy that number. That's your post ID.

Copy only the digits after posts. Anything trailing in the URL — query strings, a ? and everything after it — isn't part of the ID and will make Meta reject it.

Step 2: Use It in Your New Ad

Now duplicate the ad, or start an entirely new one — both work.

In the new ad, at the ad level, choose Use existing post instead of creating one
Scroll down and select Enter post ID
Paste in your post ID and click the check mark
Publish

The new ad now runs against the original post, and all the accumulated likes, comments and shares come with it.

When to Use This
Situation Use a post ID?
Moving a winning ad from your Testing campaign into Evergreen Yes — this is the main one
Duplicating an ad into a new ad set or audience Yes
Relaunching a proven ad after pausing it Yes
Launching brand-new creator content No — there's no post to inherit from yet
Testing a new hook or edit of the same video No — it's different creative, so it needs its own post

This pairs naturally with the graduation step in Meta Ads Best Practices — when you move the top ad from a testing ad set into Evergreen, use the post ID so it arrives with its engagement intact.

Things to Know
Post IDs are managed in Meta, not in Trybe. Trybe's Ad Builder creates new posts for new creative; using an existing post is a manual step in Ads Manager.
Trybe attribution follows the ad name, not the post. An ad built from a post ID still needs trybe=<submission ID> in its name for spend and revenue to be attributed back to the creator. If you're duplicating a Trybe-built ad, that suffix is already in the name — keep it.
Partnership ads keep their identity. A post created as a partnership ad stays under the creator's handle when reused via post ID.
Related Guides
Meta Ads Best Practices
How to Run Trybe Ads on Meta
Need Help?
Use the chat bubble in the bottom-right corner of this page
Click the "?" icon in the top-right of your Trybe dashboard
