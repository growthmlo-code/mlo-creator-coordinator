# /help/brand-guides/setting-up-creator-whitelisting
Fuente: https://jointrybe.com/help/brand-guides/setting-up-creator-whitelisting (capturado 18-sep-2026)

How to Set Up Creator Whitelisting

Partnership ads let you run a creator's content as an ad through their Instagram profile rather than your brand account. Instead of the ad feeling like it's coming from a brand, it feels like it's coming directly from the creator.

Video Walkthrough
Why Use Partnership Ads?

These ads usually perform significantly better. On Meta we currently see around 20–30% higher conversions compared to standard brand page ads. They feel more native, more trustworthy, and blend in better with what people are already used to seeing in their feed.

Nothing changes about how the ad runs

A partnership ad still runs through your Meta ad account, spends your budget, and reaches the same audience your targeting would reach anyway. It is not pushed to the creator's followers. The only difference is the ad header shows the creator's profile picture and handle instead of your brand's.

If you're already working with creators, this is one of the easiest ways to get more out of your content: same audience, same account, better conversions.

How to Request Partnership Ad Permissions
Step 1: Go to the Creators Tab

Head to the Creators tab in your dashboard and find the Partnership Ads column.

Step 2: Read the Status Icon

Each creator shows one icon. Hover over any icon to see the full status, which Instagram handle the request went to, and when Meta last confirmed it.

Icon Status What it means What to do
Gray dashes (--) Awaiting creator setup The creator hasn't connected an Instagram account yet, so there's nothing to request against Ask them to connect Instagram in their Trybe app
Envelope Off The creator hasn't been opted in yet, or no request is on record Click it to opt them in and send the request
Yellow clock Pending The request went out — the creator needs to approve it in Instagram Click to refresh. Nudge the creator if it's been a while
Green check On & active Approved and confirmed with Meta. Ready to run Nothing — you're good
Gray question mark On, unconfirmed Recorded as approved, but Meta hasn't confirmed it recently. Ads built on this may be rejected Click it to run a live check, which resolves it either way
Red warning Request refused Meta refused the request. Hover to see exactly why Fix what Meta named, then click to retry
Don't treat the question mark as approved

A gray ? is not a green check. It means the approval is on record but hasn't been verified against Meta recently — and building partnership ads on an unverified grant is a common source of post-launch Meta rejections. One click runs a live check and tells you the truth.

Step 3: Send the Request

Click the envelope icon next to a creator. That opts the creator in and sends the request. The creator receives it in two places — a DM on Instagram and an email notification — and approves it from either.

Step 4: Confirm Approval

Once the creator approves, the icon turns into a green check. Hover over it to see the Instagram handle the permission is attached to and when Meta last confirmed it.

A green check means you're ready to run partnership ads through that creator's profile. You can click it any time to force a fresh check — useful if you suspect a grant was revoked.

Creators can start this too

You don't have to be the one who sends the request. From the Trybe app, a creator can open your brand, tap the three dots in the top-right corner, choose Partnership Ads, then Activate Partnership Ads. That sends the same Instagram request, and they approve it the same way. Once they do, the green check shows up on your roster exactly as if you'd sent it.

Choosing an Identity When You Build

When you build ads for a creator with a green check, the ad builder shows a Partnership Ads toggle. Turn it on and you get three options:

Option What shows in the ad header When to use it
Dynamic identity Meta picks whichever it expects to perform best — the creator alone, or the creator and your brand together Good default if you'd rather let Meta test it
First identity only The creator's handle only Our recommended starting point — it reads the most native in the feed
Both identities The creator's handle and your brand's, side by side When you want the brand visibly attached

We typically recommend dynamic or first identity only. See Meta Ads Best Practices for how this fits into a broader testing structure, and How to Run Trybe Ads on Meta for the rest of the build flow.

What Gets Checked at Build Time

You don't have to police this manually. When you build ads, Trybe re-verifies every selected creator's grant against Meta:

Creators who aren't currently eligible get a "not partnership-eligible" badge in the selected-creatives panel
Their ads are automatically built under your brand page identity instead, so a revoked grant never becomes a failed ad
If Trybe can't reach Meta to verify at all, the review screen warns you before you launch

See How to Run Trybe Ads on Meta for the full build flow.

Troubleshooting
A creator shows dashes (--)

They haven't linked an Instagram account. Ask them to connect it from Settings → Social Accounts in their Trybe profile. Once connected, the icon becomes an envelope and you can send the request.

The Instagram account must be a professional account (Business or Creator). Personal Instagram accounts can't grant partnership ad permissions — Meta doesn't allow it.

The status went from green back to a question mark

The permission is still on record but Meta hasn't reconfirmed it. Click to run a live check. If the creator revoked access in Instagram, the check will show that, and you'll need to request again.

A creator reconnected a different Instagram

Partnership permissions are tied to a specific Instagram account. If a creator connects a different one, any permission attached to the old account is cleared and you'll need to send a fresh request against the new handle. The tooltip always shows which handle the current permission belongs to.

Ads are running under our brand page instead of the creator

That's the intended fallback when a grant can't be verified at build time. Check the creator's icon on the Creators tab — if it's anything other than a green check, resolve that first, then rebuild.

Related Guides
How to Run Trybe Ads on Meta
Meta Ads Best Practices — including partnership identity settings
How to Connect Meta
Troubleshooting Your Meta Connection
Need Help?
Use the chat bubble in the bottom-right corner of this page
Click the "?" icon in the top-right of your Trybe dashboard
