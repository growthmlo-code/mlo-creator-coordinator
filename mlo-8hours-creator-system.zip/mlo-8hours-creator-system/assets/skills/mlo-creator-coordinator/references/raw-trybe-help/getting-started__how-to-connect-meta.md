# /help/getting-started/how-to-connect-meta
Fuente: https://jointrybe.com/help/getting-started/how-to-connect-meta (capturado 18-sep-2026)

How to Connect Meta

Connect your Meta account to Trybe so you can turn approved creator content into live ads.

Before You Start

Log in with an account that has full admin access to your Meta Business Manager and your ad account. Your ad account, Facebook page and Instagram account must also be properly linked inside Business Manager — if anything isn't connected correctly, your page won't appear during setup.

A five-point checklist before you begin:

Right Facebook page, with the correct Instagram account connected to it
Right Instagram account in Business Manager (a professional account — Business or Creator)
Right ad account in Business Manager
You have access on all three, individually
A payment method on the ad account
Steps to Connect
Go to Integrations — Open the Integrations tab in your Trybe dashboard.
Connect Meta — Click Connect Meta Account. Meta will prompt you to sign in if you aren't already.
Grant permissions — Approve everything requested. Trybe needs these to create ads, read performance data, and manage partnership ads on your behalf.
Select Your Ad Account — Choose the ad account you run ads from.
Select Your Facebook Page — Pick the page linked to your brand's Instagram account.
Complete Setup — Click Complete Setup and you're done.

Your Facebook page must have a linked Instagram account for partnership ads to work. If your Instagram account isn't listed, connect it to your Facebook page in Meta Business Suite first, then reconnect.

Connecting More Than One Ad Account

You can connect several Meta ad accounts to one brand — useful if you run separate accounts per region, per brand line, or through an agency.

Add each one from the Integrations page with Connect Meta Account
One account is flagged as your default; you can change which
On the Ads page, an account switcher at the top controls which account you're working in. Campaigns, ad sets, settings and Active Ads are all scoped to the selected account
Pages are per-account

Each connected ad account has its own set of Facebook pages, and its own partnership default page — the page partnership ads run under. Partnership permissions are granted against that specific page, so changing it means existing grants may need to be requested again.

If Something Doesn't Connect

Almost every failed Meta connection is a Business Manager settings issue, not a Trybe one — most often missing access on the page, the ad account or the Instagram account, which are three separate permissions.

Work through Troubleshooting Your Meta Connection before retrying. Reconnecting won't help if the underlying setup is incomplete.

Next Steps
How to Run Trybe Ads on Meta — build and launch your first ads
Meta Ads Best Practices — campaign structure and creative testing
How to Set Up Creator Whitelisting — run ads through creators' profiles
Need Help?
Use the chat bubble in the bottom-right corner of this page
Click the "?" icon in the top-right of your Trybe dashboard
