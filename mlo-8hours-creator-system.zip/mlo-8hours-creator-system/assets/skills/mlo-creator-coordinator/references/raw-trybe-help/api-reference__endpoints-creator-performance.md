# /help/api-reference/endpoints-creator-performance
Fuente: https://jointrybe.com/help/api-reference/endpoints-creator-performance (capturado 18-sep-2026)

Endpoints — Creator performance
GET /v1/creator-performance

Returns one row per active creator with identity plus date-bounded performance metrics. This is the BI/export-friendly endpoint: sync performance for all your creators with paginated bulk requests instead of making one request per creator.

Query
Param Type Default Notes
start_date YYYY-MM-DD 30 complete UTC calendar days ago Inclusive lower UTC date.
end_date YYYY-MM-DD Yesterday in UTC Inclusive upper UTC date. Future dates rejected.
creator_id string — Optional. Restrict results to a single creator.
sort_by enum joined_at Row order. joined_at pages the roster newest-first. Any metric — earnings, trybe_gmv, trybe_conversions, new_submissions, active_submissions, ads, spend, purchase_value, purchases — ranks your whole roster by it, highest first.
program_id string — Optional. Only creators currently enrolled in this program (creator_program_<uuid>, as shown in programs[].id).
managed_by enum — Optional. partner = creators a partner agency placed and manages; brand = creators you manage directly.
active_only boolean false Drop creators with no activity in the window (every metric zero).
limit integer 20 Max 100.
after / before string — Cursor pagination (mutually exclusive). Pass the response's next_cursor back as after. Cursors are specific to the sort_by they were issued under.

Date ranges over 365 days are rejected. Ranking by a metric or using active_only aggregates your whole roster, so those requests are capped at 90 days; if such a report cannot complete for a very large roster you get a 400 invalid_request asking for a narrower window. See Conventions → Dates and timestamps for the half-open range semantics.

Response
{
"object": "list",
"data": [
{
"object": "creator_performance",
"creator": {
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe",
"avatar_url": "https://cdn.jointrybe.com/...",
"joined_at": "2025-08-12T14:23:01Z"
},
"programs": [
{ "id": "creator_program_a1b2c3d4-...", "name": "Spring 2026 UGC" }
],
"activity": {
"last_submission_at": "2026-04-30T15:12:00Z",
"last_ad_day": "2026-05-02"
},
"performance": {
"start_date": "2026-04-05",
"end_date": "2026-05-04",
"currency": "USD",
"earnings_cents": 428000,
"trybe_conversions": 142,
"trybe_gmv_cents": 4280000,
"new_submissions": 8,
"active_submissions": 5,
"ads": 12,
"spend_cents": 250000,
"purchases": 38,
"purchase_value_cents": 912000,
"roas": 3.65
}
}
],
"has_more": true,
"next_cursor": "eyJqb2luZWRfYXQi...",
"previous_cursor": null
}

Field semantics
programs — the programs the creator is currently enrolled in at your brand, { id, name } each. The same set GET /v1/creators/{id} returns, without the commission terms.
activity — all-time at your brand, not bounded by the window: last_submission_at (the creator's most recent submission, or null) and last_ad_day (the UTC date an ad last ran any of their content, or null if none ever did). This is how you see who has gone quiet without widening the window.

All performance metrics are computed for the UTC calendar date range you requested.

earnings_cents — the creator's earnings on your brand, summed over the range.
Each earning is counted on the start of the accounting period it belongs to — not the order date, not the payout date, and not the date the earning was recorded. This is the basis that lines up with brand-side reporting.
Includes earnings that are not yet finalized, so a figure can move — usually slightly upward — as they settle. If you need finalized-only values for accounting, ask your account manager: a finalized-only filter is planned.
trybe_conversions — attributed purchases whose conversion date falls in the range. A refund does not add or remove a conversion.
trybe_gmv_cents — merchandise value of those purchases, net of refunds dated in the range (a refund subtracts its value). This is the same figure as your analytics page.
new_submissions — submissions created in the range. Deleted submissions are excluded.
active_submissions — submissions that ran as a Meta ad on at least one day in the range, with impressions or spend recorded. Counted once each, however many ads they ran as. An ad counts for the submission it is tagged with — the same rule as your analytics page and the submission endpoints.
ads — distinct Meta ad ids those submissions ran as, in the same range. Expect ads >= active_submissions, because one submission can run as several ads.
spend_cents, purchases, purchase_value_cents, roas — the ad platform's own numbers for those same ads over the range: spend, purchase conversions, purchase value, and purchase_value ÷ spend (2 dp, null when spend is zero). Each ad is counted once per creator, however many of their submissions it is linked to. These are provider-reported (Meta) and measure something different from trybe_conversions / trybe_gmv_cents, which are attributed through the creator's Trybe link — never add the two.
Errors
Status Type When
400 validation_error Bad date format, start_date > end_date, range > 365 days (90 with sort_by a metric or active_only), future end_date, invalid cursor.
400 invalid_request The ranked report could not complete for the requested window (very large rosters). Narrow the window and retry.
401 invalid_api_key Missing or revoked key.
403 feature_not_enabled Brand API not enabled for your brand.
404 not_found creator_id was provided but is not active for your brand.
429 rate_limit_exceeded See Rate Limits.
Why a bulk endpoint

A BI sync usually wants every creator for a reporting period, so this endpoint pages through your whole roster rather than making you call it once per creator. New metrics arrive as new keys inside performance; existing keys will not change meaning or disappear inside v1.
