# /help/api-reference/endpoints-submissions-get
Fuente: https://jointrybe.com/help/api-reference/endpoints-submissions-get (capturado 18-sep-2026)

Endpoints — Get a submission
Get a submission
GET /v1/submissions/{id}

Returns a single submission in the same shape as the list endpoint item. Lookups are by stable Trybe submission id (submission_<uuid>).

Response
{
"object": "submission",
"id": "submission_8f3e21a0-...",
"creator": {
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe"
},
"status": "approved",
"media_type": "video",
"version": 2,
"group": null,
"products": [
{ "id": "product_8f3e21a0-...", "name": "Glow Serum" }
],
"creator_comment": "Filmed outdoors in natural light",
"review_comment": "Looks great — approved!",
"transcript": { "language": "en", "text": "..." },
"angles": [
{ "name": "GRWM", "source": "ai", "confidence": 0.82 }
],
"asset": {
"url": "https://<account>.r2.cloudflarestorage.com/.../clip.mp4?X-Amz-Expires=1200&X-Amz-Signature=...",
"expires_at": "2026-05-01T12:20:00Z"
},
"created_at": "2026-05-01T12:00:00Z"
}

See the List submissions article for the full field reference, including the short-lived asset download URL.

Errors
Status Type
400 validation_error — the id is not a valid submission_<uuid> (a bare UUID is rejected)
401 invalid_api_key
403 feature_not_enabled
404 not_found
429 rate_limit_exceeded

A 404 not_found is returned when the id doesn't exist, has been deleted, was superseded by an approved revision, or is still in partner review (and therefore not visible to your brand). These cases are intentionally indistinguishable.
