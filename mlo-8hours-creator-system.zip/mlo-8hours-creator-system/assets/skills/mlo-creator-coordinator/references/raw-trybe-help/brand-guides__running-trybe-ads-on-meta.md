# /help/brand-guides/running-trybe-ads-on-meta
Fuente: https://jointrybe.com/help/brand-guides/running-trybe-ads-on-meta (capturado 18-sep-2026)

How to Run Trybe Ads on Meta

This guide walks through the Trybe Ad Builder end to end — from your presets to a live ad in Meta Ads Manager.

This guide covers how the builder works. For how to structure your campaigns, force spend to new creative, and graduate winners, read Meta Ads Best Practices.

Before You Start

You'll need three things in place:

A connected Meta ad account — see How to Connect Meta. If your account won't connect or your page isn't listed, work through Troubleshooting Your Meta Connection first.
Approved creator submissions — only approved content can be turned into ads.
A payment method on file — the Ads page will prompt you to add one if it's missing. This is so creator commissions are ready to pay out once your ads start spending.
Running more than one ad account?

If your brand has several Meta ad accounts connected, use the account switcher at the top of the Ads page to pick which one you're working in. Campaigns, ad sets, settings and Active Ads are all scoped to the selected account — switching accounts reloads all of them. You can add, remove and set a default account on the Integrations page.

Step 1: Set Up Your Presets

Head to the Ads page and open the Settings tab. Presets fill themselves into every build, so this is the highest-leverage ten minutes you'll spend here.

Copy Templates — Save your best-performing primary texts and headlines to reuse in one click.
Landing Page Links — Save your product page URLs and set a default.
Naming Conventions — Templates for how campaigns, ad sets and ads are named (see below).
UTM Parameters — Your standard tracking parameters, automatically appended to every landing page URL.
Default CTA — The call-to-action button pre-selected when you build.

Already running ads on Meta? Use the Pull from Meta button to import copy templates and landing page URLs from ads you're already running — it saves re-typing all of it.

Naming Variables

Naming conventions have three tabs — Campaign, Ad Set and Ad — because the same variables don't make sense at every level. Insert any of these into a template:

Variable Resolves to
/creator The creator's name
/product The product name
/date 20260115
/datelong 2026-01-15
/filetype Video or Image
/identity PartnershipAd or BrandId — the identity the ad actually ran under

/creator, /product, /filetype and /identity are per-ad, so campaign and ad set names drop them (one campaign spans many ads).

You don't need to add a Trybe ID

Every ad name automatically ends with trybe=<submission ID> — that's how Meta performance gets matched back to the submission and the creator who made it. The last character of your template (_, , |, …) becomes the separator before it. If you have a legacy /trybeid in your template you can remove it.

Don't strip trybe= out of an ad name in Ads Manager after launch. Without it, that ad's spend and revenue can't be attributed back to the creator.

Step 2: Select Creator Content

From the Ads page, click Build Ads.

Filter down to what you want:

Creator — by creator name
Product — by product
Media Type — Video, Image, or all
Ad Status — Unpublished (never used in an ad), Already Running, or all
Date Range — Last 7 / 14 / 30 days, All Time, or custom
Search — by submission ID

Each card shows the creator, approval date, product, and any previous ad history.

Concepts and variants

When a creator submits several variants of the same concept, they collapse into a single concept row showing how many variants it holds. The row's checkbox selects or clears the whole concept at once, or you can expand it and pick individual variants.

Use the Unpublished filter to surface content that's never been used in an ad. Fresh creative is what your testing campaign is for.

Shortcut: build straight from the Submissions page

You can skip the selector entirely. On the Submissions page, select the submissions you want, then choose Export → Upload to Meta → Build ads. That drops you directly into the builder with those submissions already selected (up to 100 at a time).

If any selected submission has since been unapproved or deleted, the builder tells you how many it skipped rather than silently dropping them.

Step 3: Choose Where the Ads Will Live

Pick the campaign and ad set your new ads will be created in. Both selectors let you choose one or more existing containers, and both have a + button to create a new one.

New campaigns and ad sets are created by copying

Creating a new campaign or ad set here copies the settings of an existing one — budget, targeting, optimization, bid strategy — into a new object, paused, ready to launch into. There's no from-scratch option, which is deliberate: an ad set built without inherited targeting and optimization settings almost never delivers the way you expect.

When you create a new ad set, you also pick the campaign it lives in. Both are created in your Meta account immediately, before the build — so if Meta rejects something, you find out now, with the form still in front of you, rather than forty minutes into a launch.

Click the details icon next to any campaign or ad set to inspect its budget, status, targeting and optimization settings before you commit.

Each submission you selected becomes an ad in every campaign and ad set combination you choose. 3 submissions across 2 ad sets creates 6 ads.

If creating a campaign or ad set fails

The dialog stays open with your form intact and shows you exactly what Meta said — most of these are settings problems in your Meta account that you can fix and retry on the spot. Common ones:

What Meta says What to do
"The same optimization for ad delivery selection is required if the campaign bid strategy is lowest cost with bid cap…" The ad set you're copying uses a different optimization goal than the destination campaign allows. Pick a different source ad set, or change the campaign's bid strategy.
"You can only have up to 200 active and inactive ad sets in a campaign with budget…" Delete or archive ad sets in that campaign first.
"You can only set an ad set budget or a campaign budget." The campaign uses CBO — don't copy from an ad set that carries its own budget.
"All ad sets under the same campaign must use the same attribution type…" Match the attribution setting of the ad sets already in that campaign.
A Custom Audience terms-of-service error Accept Meta's Custom Audience terms in Business Manager, then retry.
Step 4: Configure Your Ad Preferences
Ad Name

Your naming template from Settings is pre-filled. Edit it here if this build needs something different.

Ad Identity
Brand Page — the ad runs from your brand's Facebook page and its linked Instagram. You choose which Facebook page from the Facebook Page selector; only pages your ad account can currently advertise from are listed.
Partnership Ads — the ad runs under the creator's Instagram handle, so it reads as creator content in the feed. Requires the creator to have granted partnership permissions — see How to Set Up Creator Whitelisting.
Partnership ads pin the page

When you choose Partnership Ads the page selector locks to your partnership default page. Branded content has to run under the exact page and Instagram account the creator granted permission to — running it under a different page is what Meta rejects.

Watch for the eligibility badges

As you build, Trybe re-checks each selected creator's partnership grant against Meta directly — a creator can revoke access in Instagram at any time, and the stored status doesn't know until it's checked.

Any selected creator who isn't currently eligible gets a "not partnership-eligible" badge in the selected-creatives panel. Those creators' ads are automatically built under your brand page identity instead, so a revoked grant never becomes a failed ad. If you'd rather not run them at all, deselect them.

Ad Copy

Select a saved template, or enter up to 5 primary texts and 5 headlines manually. Meta tests the combinations and optimizes toward the best performer. Pull from Meta imports copy from your top-performing recent ads.

Landing Page

Enter the destination URL or pick a saved link. UTM parameters from Settings are appended automatically.

Send traffic directly to the product page shown in the video. Matching the landing page to the creative is one of the cheapest conversion-rate wins available.

Call to Action

Pick the button — Shop Now, Learn More, Sign Up, and so on.

Launch As
Paused — ads are created but don't deliver until you turn them on in Ads Manager. Use this when you want to review in Meta first.
Active — ads start delivering as soon as they're created.
Step 5: Review & Launch

You'll see every ad that's about to be created before anything goes live.

The summary shows total ads, campaigns, ad sets, and the split between brand page and partnership ads. Expand any campaign or ad set to inspect individual ads, and click the pencil icon to edit an ad name or URL inline.

If you see a partnership-verification banner

A banner reading "couldn't verify partnership permissions" means Trybe couldn't reach Meta to confirm those grants. Those ads will be built under your brand identity rather than the creator's. You can proceed, or deselect the affected creators and come back once verification succeeds.

When it looks right, click Launch Ads.

Step 6: What Happens After Launch

Ad creation runs in the background — you can leave the page. A progress banner at the top of the Ads page tracks how many ads have been created.

If some ads fail

Large builds can partially fail — one Meta rejection can take out a batch of ads. When that happens the banner lists one block per distinct reason, naming every creator affected, so you can see what actually went wrong rather than the same sentence repeated a hundred times.

Errors that came from Meta are tagged with a "From Meta" chip and show Meta's own explanation. That distinction matters: a "From Meta" error is a setting in your ad account you can go fix — an ad account spending limit, a rejected page, a permissions gap — not a problem with Trybe.

You'll then see one or both of these:

Rebuild N ads — retries the ads that are safely retryable, in place.
Rebuild N ads in the ad builder — reopens the failed submissions in the builder with your selection restored, so you can change whatever caused the failure and launch again.

Whether a rebuild is offered is decided on the server, based on what it could confirm in your Meta account — the goal is that a rebuild can never quietly duplicate an ad that actually did go live. If an ad isn't retryable, the reason is shown next to it.

If your build partially failed and the activation step failed, your ads exist but are paused and won't deliver. The banner says so explicitly — check Ads Manager and turn them on.

Step 7: Monitor Your Ads

The Active Ads tab mirrors your Meta structure in three levels:

Campaign — expand to see ad sets
Ad Set — expand to see ads
Ad — creator, product, 7-day spend, 7-day ROAS

Sort by spend, ROAS, launch date or name, and filter by creator or product. New ads may show a Syncing badge until Meta confirms they're live.

Active Ads is a high-level overview. For breakdowns, trends and deeper reporting, use the Analytics page.

Not seeing performance data on an ad?

Trybe matches Meta performance back to a submission using the trybe=<id> suffix in the ad name. If an ad was created outside Trybe, or its name was edited to remove that suffix, it won't report spend or ROAS against the creator.

Related Guides
Meta Ads Best Practices — campaign structure, testing, and scaling
How to Use Post IDs on Meta — keep likes and comments when you duplicate an ad
How to Set Up Creator Whitelisting — partnership ad permissions
Troubleshooting Your Meta Connection
Need Help?
Use the chat bubble in the bottom-right corner of this page
Click the "?" icon in the top-right of your Trybe dashboard
