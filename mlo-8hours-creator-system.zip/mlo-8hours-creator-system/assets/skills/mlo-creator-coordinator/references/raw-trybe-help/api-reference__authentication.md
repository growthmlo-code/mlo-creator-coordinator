# /help/api-reference/authentication
Fuente: https://jointrybe.com/help/api-reference/authentication (capturado 18-sep-2026)

Authentication

The Brand API uses bearer-token authentication. Every request must include an Authorization header:

Authorization: Bearer tk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxx

API keys are scoped to the brand they were issued for. They cannot be used to access data for any other brand.

Key format

Keys start with the prefix tk_live_ followed by a 32-character random suffix. The first 12 characters (e.g. tk_live_a4f9) are shown in the brand portal as a display identifier; the rest is secret.

Storage

Trybe stores only a SHA-256 hash of the key. We cannot recover the plaintext key for you. If you lose it, rotate the key.

Lifecycle
Action Effect
Create Generates a new key. Plaintext is shown once in the modal.
Rotate Generates a new key and immediately revokes the previous one. There is no grace period.
Revoke Immediately invalidates the active key.

A brand can have at most one active key at a time in v1.

Permissions

Only brand owners and admins can create, rotate, or revoke API keys. Non-admin team members cannot see the API Access section.

Review actions taken via the API (approve / reject / request-revision) are attributed in your brand's audit trail to the team member who created the API key, with the action recorded as coming via the API.

Feature gating

API access is enabled per-brand by your Trybe account manager, and individual endpoint groups may be enabled separately. If your key is valid but your brand doesn't have access to a given endpoint, the request returns 403 feature_not_enabled. The articles in this section only cover the endpoints your brand can use — if you need access to something you don't see, contact your account manager.

Security best practices
Treat the key like a password. Store it in a secrets manager (AWS Secrets Manager, Doppler, 1Password, GitHub Actions secrets, etc.) — never in source control.
Use HTTPS only. The API rejects plain HTTP at the proxy layer.
Rotate the key any time you suspect it has been exposed.
Use the same key for all of your machines — but if you have multiple unrelated integrations, treat exposure of any one of them as exposure of all of them and rotate.
Multiple-keys-per-brand and IP allowlists are on the roadmap; until then, rotation is the kill switch.
