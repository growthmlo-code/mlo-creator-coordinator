# /help/api-reference/errors
Fuente: https://jointrybe.com/help/api-reference/errors (capturado 18-sep-2026)

Errors

All Brand API error responses use the same envelope:

{
"error": {
"type": "validation_error",
"message": "start_date must be on or before end_date",
"doc_url": "https://jointrybe.com/help/api-reference/errors"
}
}

Pin client logic on the type field, not the human-readable message (which can change without notice). Status codes are also stable, but type is the most precise discriminator.

Stable error types
Type Status When it fires
validation_error 400 Query/path/body validation failed: bad date format, invalid cursor, mutually exclusive params, limit out of range, an unknown query parameter (e.g. cursor instead of after), a bare id without its prefix, or a missing/empty comment when requesting a revision.
invalid_request 400 Request is syntactically valid but semantically unsupported. For example, trying to review a submission that is not pending (already approved, rejected, or revision-requested).
invalid_api_key 401 Missing, malformed, unknown, or revoked API key.
feature_not_enabled 403 The key is valid, but your brand doesn't have access to the endpoint you called. Contact your account manager to request access.
not_found 404 Resource not found, or not visible to the authenticated brand — e.g. a creator not active for the brand, or a submission that is deleted, superseded, or still in partner review.
rate_limit_exceeded 429 Pre-auth or post-auth rate limit hit. See Rate Limits.
internal_error 500 Unexpected server error. Safe to retry with backoff.
What clients should do
400 / 404 — fix the request, do not retry.
401 — re-issue the key (rotate) and update your secret store.
403 — contact your Trybe account manager to enable API access.
429 — back off and retry per retry-after header.
5xx — retry with exponential backoff. If the issue persists, contact support.
