# /help/api-reference/conventions
Fuente: https://jointrybe.com/help/api-reference/conventions (capturado 18-sep-2026)

Conventions
Response envelope

Single resources are returned as the resource itself, decorated with an object discriminator:

{
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe",
"joined_at": "2025-08-12T14:23:01Z"
}

Lists wrap items in a list envelope with cursor pagination:

{
"object": "list",
"data": [ /* items */ ],
"has_more": true,
"next_cursor": "eyJqb2luZWRfYXQi...",
"previous_cursor": null
}

Pagination (cursor-based)
Pass limit (default 20, max 100), and either after or before (mutually exclusive).
next_cursor walks forward (older rows). Pass its value back as ?after=... on the next request.
previous_cursor walks backward (newer rows). Pass its value back as ?before=....
Cursors are opaque — do not parse, decode, or construct them yourself. Their format may change.
has_more is true when more rows are available in the direction you're paging.

Note the param name. The response field is next_cursor, but the request parameter you send it back in is after (there is no cursor parameter). Unknown query parameters are rejected with a 400 validation_error — so a request like ?cursor=... fails loudly rather than silently returning the first page again. To page through all results:

GET /v1/creators?limit=100
# then, while has_more is true, repeat with the previous response's next_cursor:
GET /v1/creators?limit=100&after=<next_cursor>

Stable sort: results are ordered by joined_at DESC, id DESC so cursor pagination is consistent across requests.

Money
All monetary values are returned as integer cents (no floats). 4280000 means $42,800.00.
All values are in USD. Trybe stores monetary data normalized to USD across regions; per-brand currencies are not exposed in v1.
Responses include "currency": "USD" for explicitness.
Dates and timestamps
Dates are YYYY-MM-DD (no time component).
Timestamps are ISO 8601 with a Z suffix (UTC).
Date filters operate on UTC calendar dates, not on your brand's timezone. A request for start_date=2026-04-05&end_date=2026-05-04 is evaluated as timestamp >= 2026-04-05T00:00:00Z AND timestamp < 2026-05-05T00:00:00Z (half-open).
Default performance range is the last 30 complete UTC calendar days (excludes today).
Maximum performance range is 365 days. Wider ranges return validation_error.
end_date must be on or before yesterday in UTC. Today and future dates are rejected — only complete UTC days are queryable.
IDs

All ids are prefixed strings. Treat them as opaque — do not parse the prefix or assume a specific suffix shape; the underlying format may change between versions. Always store and pass back the full prefixed id; a bare UUID is rejected with a 400 validation_error.

Prefix Resource
creator_ A creator
program_ A program enrollment
submission_ A submission
subgroup_ A submission group (a set of variants on one concept)
product_ A product tagged on a submission
