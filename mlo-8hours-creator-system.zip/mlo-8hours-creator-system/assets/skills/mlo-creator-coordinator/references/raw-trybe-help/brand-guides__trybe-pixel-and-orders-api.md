# /help/brand-guides/trybe-pixel-and-orders-api
Fuente: https://jointrybe.com/help/brand-guides/trybe-pixel-and-orders-api (capturado 18-sep-2026)

Trybe Pixel and Orders API

This guide walks you through installing the Trybe attribution pixel on your website and submitting orders via our server-side API. The pixel tracks visitor behavior and attributes conversions to your creators at the video level.

Non-Shopify Stores Only

This guide is for brands running non-Shopify stores (custom sites, WooCommerce, BigCommerce, headless commerce, etc.). If your store is on Shopify, you should install our Shopify app directly from the Brand Portal → Integrations page instead of following this guide. The Shopify app handles all tracking and order attribution automatically.

How It Works

The Trybe attribution system has two parts:

Client-side pixel — a lightweight JavaScript snippet that tracks page views, product views, add-to-cart events, and checkout events in the browser
Server-side Orders API — a secure API endpoint where your server submits completed orders for accurate conversion attribution

Together, these connect creator-driven traffic to actual purchases on your store.

Step 1: Set Up Your Tracking Domain

To get started, you'll configure a custom tracking subdomain on your own domain (e.g. track.yourdomain.com). This ensures the pixel loads as a first-party script, which prevents ad blockers from interfering with tracking and keeps data accuracy at 95%+.

Log into your Trybe Brand Portal
Navigate to Integrations and select the Universal Pixel option
Enter a custom tracking subdomain (e.g. track.yourdomain.com)
Add a CNAME DNS record pointing your subdomain to proxy.jointrybe.com:
Type: CNAME
Name: track
Value: proxy.jointrybe.com
TTL: 3600

Click Check DNS in the Brand Portal to verify — SSL certificates are provisioned automatically
Once verified, the portal will generate your Pixel Code (starts with px_), Store ID, and Orders API Key (starts with sk_)
Copy these values — you'll need them in the following steps
Step 2: Install the Pixel

Add the following snippet to the <head> section of every page on your site:

<script>
(function(w,d,p,s,u,pl,at) {
w._trybe = w._trybe || {
pixelCode: p,
storeId: s,
platform: pl,
autoTracking: at
};
var script = d.createElement('script');
script.src = u + '/pixel.js';
script.async = true;
script.setAttribute('data-pixel-code', p);
script.setAttribute('data-store-id', s);
script.setAttribute('data-platform', pl);
script.setAttribute('data-auto-tracking', at);
d.head.appendChild(script);
})(window, document,
'YOUR_PIXEL_CODE',
'YOUR_STORE_ID',
'https://track.yourdomain.com',
'custom',
'false'
);
</script>

Replace YOUR_PIXEL_CODE, YOUR_STORE_ID, and track.yourdomain.com with the values from your Brand Portal.

Auto-Tracking

If your site uses a standard e-commerce platform (WooCommerce, BigCommerce, Wix), you can set the last parameter to 'true' to enable auto-tracking. This automatically detects product pages, add-to-cart actions, and checkout events without additional code. For fully custom sites, keep it as 'false' and use the manual tracking methods below.

Step 3: Track Events (Manual Tracking)

Once the pixel is loaded, a window.trybe object becomes available with the following methods.

Product Viewed

Call this on product detail pages:

window.trybe.productViewed({
productId: 'prod_123',
productName: 'Awesome T-Shirt',
price: 29.99,
currency: 'USD'
});

Field Type Required Description
productId string Yes Unique product identifier
productName string No Product display name
price number Yes Product price
currency string Yes 3-letter ISO 4217 currency code in uppercase (e.g. USD, EUR, GBP, ZAR)
category string No Product category
Add to Cart

Call this when a user adds a product to their cart:

window.trybe.addToCart({
productId: 'prod_123',
productName: 'Awesome T-Shirt',
quantity: 2,
price: 29.99,
currency: 'USD'
});

Field Type Required Description
productId string Yes Unique product identifier
productName string No Product display name
quantity number No Quantity added (defaults to 1)
price number Yes Product price
currency string Yes 3-letter ISO 4217 currency code in uppercase (e.g. USD, EUR, GBP, ZAR)
Checkout

Call this on your order confirmation / thank-you page:

window.trybe.checkout({
orderId: 'order_456',
value: 59.98,
currency: 'USD',
email: 'customer@example.com'
});

Field Type Required Description
orderId string Yes Unique order identifier
value number Yes Total order value
currency string Yes 3-letter ISO 4217 currency code in uppercase (e.g. USD, EUR, GBP, ZAR)
email string No Customer email (automatically hashed for privacy)
Generic Event Tracking

For any custom events not covered above, use the generic track method:

window.trybe.track('EventName', {
key: 'value'
});

This accepts any event name and an optional properties object.

Get Visitor ID

To retrieve the current visitor's ID (needed for the server-side Orders API):

var visitorId = window.trybe.getVisitorId();

Step 4: Submit Orders via the Server-Side API
Important

Client-side tracking can be blocked by ad blockers or fail due to JavaScript errors. For accurate conversion tracking, always submit completed orders from your server using this API in addition to client-side tracking.

Endpoint
POST https://jointrybe.com/attribution/v1/orders
Content-Type: application/json

Request Body
{
"apiKey": "sk_your_api_key_here",
"orderId": "order_456",
"value": 59.98,
"currency": "USD",
"vid": "visitor-uuid-from-cookie",
"email": "customer@example.com",
"orderTime": "2026-03-25T10:30:00Z",
"items": [
{
"productId": "prod_123",
"productName": "Awesome T-Shirt",
"quantity": 2,
"price": 29.99
}
]
}

Field Reference
Field Type Required Description
apiKey string Yes Your private API key from the Brand Portal (NOT the pixel code)
orderId string Yes Unique order identifier
value number Yes Total order value
currency string Yes 3-letter ISO 4217 currency code in uppercase (e.g. USD, EUR, GBP, ZAR). The API will reject unrecognized codes with a 400 error.
vid string Yes Visitor ID from the pixel cookie
email string Recommended Customer email (hashed automatically on our end)
orderTime string No ISO 8601 timestamp (defaults to current time)
items array No Array of line items in the order
Keep Your API Key Secret

The apiKey is your private server-side key. Never expose it in client-side JavaScript or commit it to a public repository.

Getting the Visitor ID (VID)

The pixel stores a visitor ID in a first-party cookie on your domain. To read it server-side:

Cookie name: ugc_vid or ugc_vid_{storeId} if you provided a Store ID.

Node.js example:

const vid = req.cookies['ugc_vid_YOUR_STORE_ID'];

PHP example:

$vid = $_COOKIE['ugc_vid_YOUR_STORE_ID'];

You can also pass the VID from the browser to your server using window.trybe.getVisitorId() — for example, by including it as a hidden form field or sending it alongside your checkout request.

Example: Node.js Order Submission
const axios = require('axios');

async function submitOrderToTrybe(order, visitorId) {
const response = await axios.post(
'https://jointrybe.com/attribution/v1/orders',
{
apiKey: process.env.TRYBE_API_KEY,
orderId: order.id,
value: order.total,
currency: order.currency,
vid: visitorId,
email: order.customerEmail,
orderTime: order.createdAt,
items: order.items.map(item => ({
productId: item.productId,
productName: item.name,
quantity: item.quantity,
price: item.price
}))
}
);

return response.data;
}

API Response

Success (200):

{
"success": true,
"message": "Order queued for attribution processing",
"data": {
"orderId": "order_456",
"eventId": "evt_abc123",
"queuedAt": "2026-03-25T10:30:00Z"
}
}

Duplicate Order (409):

{
"success": false,
"error": "Duplicate order",
"message": "Order with ID \"order_456\" has already been processed"
}

Example: Full GTM Integration

If you use Google Tag Manager, you can fire tracking calls using Custom HTML tags:

Product View Tag (fires on product page):

<script>
window.trybe && window.trybe.productViewed({
productId: '{{Product ID}}',
productName: '{{Product Name}}',
price: {{Product Price}},
currency: '{{Currency Code}}'
});
</script>

Add to Cart Tag (fires on add-to-cart event):

<script>
window.trybe && window.trybe.addToCart({
productId: '{{Product ID}}',
productName: '{{Product Name}}',
quantity: {{Quantity}},
price: {{Product Price}},
currency: '{{Currency Code}}'
});
</script>

Checkout Tag (fires on order confirmation page):

<script>
window.trybe && window.trybe.checkout({
orderId: '{{Order ID}}',
value: {{Order Total}},
currency: '{{Currency Code}}',
email: '{{Customer Email}}'
});
</script>

Replace the double-brace values (e.g. {{Product ID}}) with your GTM Data Layer variables.

Testing Your Integration
Open your browser's Developer Tools → Console
Navigate to a product page and check for: [Trybe] Pixel initializing with code: px_...
Test a product view manually in the console:
window.trybe.productViewed({
productId: 'test_123',
productName: 'Test Product',
price: 9.99,
currency: 'USD'
});

Check the Network tab for requests to /v1/pixel/events — you should see a 200 response
Use window.trybe.getVisitorId() in the console to verify a visitor ID is being generated
Troubleshooting
window.trybe is undefined — The pixel script hasn't loaded yet. Make sure the snippet is in the <head> and that _trybe.pixelCode is set correctly. Check for ad blockers or script-blocking browser extensions.
Events not appearing — Check the Network tab for failed requests to /v1/pixel/events. If requests are being blocked, consider setting up a custom tracking domain.
Duplicate events being skipped — This is expected. The pixel has built-in deduplication: product views are tracked once per product per page load, add-to-cart events are deduplicated within a 2-second window, and checkout is tracked once per session.
Orders API returning 403 — Your API key is invalid or disabled. Double-check the key in the Brand Portal under Integrations.
Orders API returning 429 — You've exceeded the rate limit. Retry after the Retry-After header value.
API Method Reference
Method Description
window.trybe.productViewed(data) Track a product page view
window.trybe.addToCart(data) Track an add-to-cart event
window.trybe.checkout(data) Track checkout completion
window.trybe.track(eventName, properties) Track a custom event
window.trybe.getVisitorId() Get the current visitor ID
Need Help?

If you run into issues with your pixel integration, reach out to your Trybe account manager or contact our support team.
