# /help/api-reference/endpoints-submissions-review
Fuente: https://jointrybe.com/help/api-reference/endpoints-submissions-review (capturado 18-sep-2026)

Endpoints — Review a submission

Review actions let you approve, reject, or request revisions on a submission programmatically. Each action has its own endpoint:

POST /v1/submissions/{id}/approve
POST /v1/submissions/{id}/reject
POST /v1/submissions/{id}/request-revision

These actions have real side effects. A review via the API behaves identically to reviewing in the brand portal — the creator cannot tell the action came from the API. Approving fires the creator's earnings for the submission and sends them a notification; rejecting and requesting a revision also notify the creator. Treat these endpoints with the same care as the in-app review buttons.

Body
{ "comment": "Looks great!" }

Action comment
approve Optional.
reject Optional.
request-revision Required, non-empty. Tells the creator what to change.

A missing or empty comment on request-revision returns 400 validation_error.

Pending-only

A submission can only be reviewed while its status is pending. Reviewing a submission in any other state (approved, rejected, revision_requested) returns:

{
"error": {
"type": "invalid_request",
"message": "Submission can only be reviewed while it is pending.",
"doc_url": "https://jointrybe.com/help/api-reference/errors"
}
}

with status 400. This same PENDING-only rule prevents accidental double-reviews — once the first action lands, the submission is no longer pending.

Response

200 OK with the updated submission, in the same shape as the Get a submission response. The status reflects the new state, and review_comment reflects the comment you just sent.

{
"object": "submission",
"id": "submission_8f3e21a0-...",
"status": "approved",
"review_comment": "Looks great!",
"...": "..."
}

Errors
Status Type
400 validation_error — invalid id, or missing/empty comment on request-revision
400 invalid_request — the submission is not pending
401 invalid_api_key
403 feature_not_enabled
404 not_found — submission doesn't exist, is deleted/superseded, or is not visible to your brand
429 rate_limit_exceeded
