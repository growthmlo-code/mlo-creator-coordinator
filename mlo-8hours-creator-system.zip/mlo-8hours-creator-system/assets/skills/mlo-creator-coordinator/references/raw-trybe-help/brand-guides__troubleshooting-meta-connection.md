# /help/brand-guides/troubleshooting-meta-connection
Fuente: https://jointrybe.com/help/brand-guides/troubleshooting-meta-connection (capturado 18-sep-2026)

Troubleshooting Your Meta Connection

If your Meta integration isn't working on Trybe, it's almost always an issue in your Meta Business Manager settings — not in Trybe. This video walks through exactly what to check, and the written checklist below follows the same order.

Work through this before you try reconnecting again. Reconnecting won't help if the underlying Business Manager setup is missing something — you'll just land back on the same screen with the same missing page.

Step 1: Check your Facebook Page

Open Meta Business Manager and click into Pages.

Make sure the correct Facebook page is listed there.
Click into the page and go to People — confirm that you, or whoever is connecting Trybe to Meta, has access.
Still on the page, go to Connected assets — confirm the correct Instagram account is connected.
Step 2: Check your Ad Account

Click into Ad Accounts.

Make sure the correct ad account is linked to your Business Manager.
Under People, confirm that you, or whoever is connecting Trybe to Meta, has access here too.
Step 3: Check your Instagram Account

Click into Instagram accounts.

Make sure the correct Instagram account is in your Business Manager.
Under People, confirm that you, or whoever is connecting Trybe to Meta, has access.
Under Connected assets, confirm your Facebook page is showing as a connected asset.

Notice that access is checked in three separate places — the page, the ad account, and the Instagram account. Having access to one does not give you access to the others, and this is the most common thing people miss.

Step 4: Start the integration in Trybe

Head over to the Trybe portal and start the integration from the Integrations page.

When you connect, make sure the correct ad account is populating.
Then select the right page or pages.
Page not showing up?

If the page you need isn't appearing in the list, that means something got missed back in your Meta Business Manager settings. Go back through Steps 1–3 and check again — the page will only appear in Trybe once it's set up correctly on Meta's side.

The quick checklist

That's it. Before you connect, confirm all five:

Right Facebook page
Right Instagram account
Right ad account
Right people with access on each of them
Everything populating correctly in Trybe

Once that all checks out, you're good to go.

If ads failed to build

A connection that works can still produce a failed ad build — usually because of a setting in your Meta ad account rather than anything in Trybe.

Tell a Meta problem from a Trybe one

Every ad error Trybe shows you is labelled. Errors that came back from Meta carry a "From Meta" chip and show Meta's own explanation of what it rejected. That's the signal to go look in your Meta account — an ad account spending limit, a page restriction, a permissions gap, an account-quality flag — rather than opening a ticket with us.

Errors without that chip are ours, and those are worth reporting.

Read the failure list, not the first line

When a build partially fails, the banner groups failures one block per distinct reason and names every creator affected. A single Meta rejection can take out a large batch of ads, so the list tells you whether you're looking at one fixable setting or several different problems.

Rebuild after you've fixed it

Depending on what Trybe could confirm in your Meta account, you'll see one or both:

Rebuild N ads — retries the safely retryable ads in place
Rebuild N ads in the ad builder — reopens the failed submissions in the builder so you can change what caused the failure and relaunch

If an ad can't be rebuilt automatically, the reason is shown next to it. That gate exists so a rebuild can never quietly duplicate an ad that actually did go live.

Partially failed, and paused?

If the activation step also failed, your ads exist in Meta but are paused and won't deliver. The banner says so explicitly — go turn them on in Ads Manager.

Common ad account causes
Symptom Usually means
Every ad in a build failed with the same Meta error An ad account level problem — spending limit reached, payment method declined, or an account quality restriction
"Permissions error" from Meta Your Meta login lost access to the ad account, the page, or the Instagram account. Re-check all three (Steps 1–3 above)
A Custom Audience terms error Accept Meta's Custom Audience terms in Business Manager, then rebuild
Ads built under your brand page when you chose partnership The creator's grant couldn't be verified — see How to Set Up Creator Whitelisting
Ads created but reporting no spend or ROAS in Trybe The trybe=<id> suffix was removed from the ad name in Ads Manager. Trybe matches performance on that suffix
Need Help?
Reconnecting because tracking stopped? See Troubleshooting Attribution.
Setting up ads once you're connected: How to Run Trybe Ads on Meta.
Campaign structure and creative testing: Meta Ads Best Practices.
Still stuck? Click the "?" icon in your Trybe account and hit Chat Now.
