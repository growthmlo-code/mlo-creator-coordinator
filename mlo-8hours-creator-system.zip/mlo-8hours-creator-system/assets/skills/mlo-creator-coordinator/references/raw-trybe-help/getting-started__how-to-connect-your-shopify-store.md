# /help/getting-started/how-to-connect-your-shopify-store
Fuente: https://jointrybe.com/help/getting-started/how-to-connect-your-shopify-store (capturado 18-sep-2026)

How to Connect Your Shopify Store

Learn how to connect your Shopify store to Trybe so you can start tracking creator-driven sales automatically.

Before You Start

The person completing this setup must have owner or admin access to your Shopify store. Without the proper permissions, the connection won't go through.

Steps to Connect
Go to Integrations — Head to the Integrations tab in your Trybe dashboard.
Select Shopify — Click Shopify Store, then select Get Started with Shopify Store.
Install the App — You'll be redirected to Shopify and prompted to install the Trybe Attribution app. Click Install.
Connect to Trybe — After the app installs, click Connect to Trybe.
Select Your Brand — Choose the brand you want to connect the store to and confirm your selection.

That's it — your Shopify store is now connected to Trybe.

Need Help?

If the connection isn't going through, double-check that you have owner or admin permissions on your Shopify store. For further assistance, click the "?" icon in the top-right of your Trybe dashboard.
