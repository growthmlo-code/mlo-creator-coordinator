# /help/brand-guides/program-agreements-and-the-compliance-check
Fuente: https://jointrybe.com/help/brand-guides/program-agreements-and-the-compliance-check (capturado 18-sep-2026)

Program Agreements and the Compliance Check

A program agreement is a PDF you attach to a creator program. Enrolled creators must accept it before they can submit, and any time you change it they're asked to accept the new version.

Most programs don't need one. Every creator on Trybe has already agreed to Trybe's Creator Terms, and every brand to the Brand Terms. Together they already cover content ownership, licensing, usage in ads, and payment. An agreement is for the things those terms leave open to you: exclusivity for a bounded period, a non-disparagement clause, deliverable specs, confidentiality about unreleased products.

The one rule

Your agreement sits on top of the Creator Terms. It can add to them. It cannot contradict them.

Before an agreement reaches a creator, Trybe reviews it against the Creator Terms. If a clause conflicts, the agreement doesn't go live and you're shown the exact clause and a suggested rewrite.

What the review looks for

These are the clause types that conflict with the Creator Terms. The card on your program names the specific ones found in your document and quotes them.

What we found What it means What passes instead
Transfers ownership of the creator's content "Work made for hire", "assigns all right, title and interest" The creator keeps ownership; you receive a licence
Keeps rights to the content after payment stops "Perpetual", "irrevocable", "survives termination", or a fixed term such as "12 months from approval", on a commission program On a commission program your licence lasts as long as commissions are paid. Only a program whose sole rule is a flat fee per approved submission may hold a perpetual licence
Claims rights to content you never accepted or paid for Rights "on submission", to "all content submitted", to raw footage or outtakes Rights begin when you accept and pay for a piece
Stops the creator using their own content Bans on portfolio or own-channel use Creators may use their own work in their portfolio
Changes the terms without the creator re-accepting "Continued participation constitutes acceptance", rates "provided separately", "as amended from time to time" Change the agreement in Trybe; creators are re-prompted automatically
Moves payment or contracting off Trybe PayPal, bank transfer, invoicing you directly, an affiliate network, a separate contract Creators are paid through Trybe. Asking creators to join a Discord or WhatsApp for coordination is fine
Replaces the program's pay with product or store credit "No commission is payable", "content is the compensation", store credit instead of cash Product plus the program's pay. A free sample "in exchange for" content is fine on its own
Defers to terms the creator was never shown A link or document that isn't in the PDF Put the terms in the PDF
Withholds earned pay or requires unpaid extra work Set-off against earned commissions, forfeiting all unpaid earnings on any breach, mandatory extra deliverables at no charge Earned commissions are paid; extra work is paid work

You may also see "No eligible creator agreement was found". That means the file in the Agreements slot reads as a brief, a guideline sheet or an unfinished template rather than binding terms. If it's a brief, it belongs in the program's Brief section.

The states you'll see

On Creators → Programs, open the program, then Customize → Agreements. An amber warning chip in the sidebar means the section needs you.

Paused. Your live agreement had a conflicting clause. Creators in the program can submit without accepting it. Nothing else about the program changed: commissions, briefs, approvals and payouts all run exactly as before, and Trybe's Creator Terms and Brand Terms still govern every submission. The agreement isn't deleted; it's waiting for you to revise.
Blocked. A new or replacement upload can't go live. If you had a previous version live, it stays live and creators keep accepting that one.
In review. Our automated review couldn't decide, so a person at Trybe is reading it. Your previous live version stays live in the meantime. No action needed.
Couldn't review. A temporary failure. Nothing changed for your creators. Use Try again.
Live. Passed review and gating creators as normal.
How to fix a paused or blocked agreement
Open Creators → Programs, select the program, Customize → Agreements.
Read the clauses we quoted and the suggested rewrite under each.
Either Upload revised PDF, or Remove agreement and rely on Trybe's terms.

A revised upload is reviewed automatically, usually within a few minutes. As soon as it passes, it goes live and every creator in the program is prompted to accept it before they can submit again. Your terms are back in force from that moment.

A quick test for what passes: the creator keeps ownership; your licence begins when you accept and pay for a piece; on a commission program it lasts as long as commissions are paid; and payment and any changes to terms happen through Trybe.

The card shows the clauses our review found. A revised document is reviewed in full, so it's possible for a later upload to be flagged on a clause that wasn't mentioned the first time.

If you think we've read a clause wrong

Reply to the email you received or contact support from the Agreements card. A person will look at the clause and the reading. Common clauses that brands ask about, and why they're flagged:

A perpetual, non-exclusive licence for organic use. Common in the industry, but on a commission program the creator's pay is the commission. A licence that outlives the commissions means using work you've stopped paying for. Tie the licence to the commission relationship, or move the program to a flat fee per approved submission.
Paying through your affiliate network or PayPal. Creators on Trybe are paid through Trybe. That's the product.
A six- or twelve-month usage window. Same reasoning as perpetual: the window is measured in calendar time, not in whether commission is still being paid. Tie it to payment instead.
For creators

If a brand's agreement disappears from your view, or you can submit without being asked to accept anything, the brand's agreement is paused while they revise it. Your submissions are governed by Trybe's Creator Terms and the brand's program rules as usual. You'll be prompted to accept the revised version when the brand publishes it.
