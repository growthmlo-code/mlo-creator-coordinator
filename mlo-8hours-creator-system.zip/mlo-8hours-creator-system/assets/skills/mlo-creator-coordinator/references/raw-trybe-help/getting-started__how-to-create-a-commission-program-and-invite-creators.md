# /help/getting-started/how-to-create-a-commission-program-and-invite-creators
Fuente: https://jointrybe.com/help/getting-started/how-to-create-a-commission-program-and-invite-creators (capturado 18-sep-2026)

How to Create a Commission Program & Invite Creators

Learn how to set up a commission program for your creators and start sending invite links.

Create a Commission Program
Go to Creators — Head to the Creators tab in your Trybe dashboard.
Start a New Program — Click Commission Programs, then select Create Program.
Name Your Program — Give your commission program a name.
Choose a Payout Trigger — This determines how often commissions are paid out to your creators.

We recommend selecting weekly payouts — creators tend to produce more consistently when payouts are more frequent.

Set Your Commission Structure — Choose from:

Percentage of sales
Dollar amount per approved submission
Dollar amount per approved order
Meta-based metric

You can also combine multiple rules to create a custom structure.

In most cases, a percentage of sales drives the strongest performance for brands, but you can structure this however works best for your program.

Create the Program — Once everything looks good, click Create Program.
Invite Creators
Get Your Invite Link — Click Creator Invite Link, then select the commission program you just created. This copies an invite link to your clipboard.
Share the Link — Send the link to your creators however you prefer — group chat, DM, email, or any other channel.
Creators Sign Up — When creators click the link, they'll be prompted to sign up or log in and accept the invitation. Once they do, they're added to your commission program and ready to go.
Need Help?

If you have questions about structuring your commission program, click the "?" icon in the top-right of your Trybe dashboard to reach our support team.
