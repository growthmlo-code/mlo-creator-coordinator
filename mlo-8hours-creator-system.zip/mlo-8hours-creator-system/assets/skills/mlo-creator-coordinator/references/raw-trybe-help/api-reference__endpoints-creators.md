# /help/api-reference/endpoints-creators
Fuente: https://jointrybe.com/help/api-reference/endpoints-creators (capturado 18-sep-2026)

Endpoints — Creators
List creators
GET /v1/creators

Returns the creators currently active on your brand — enrolled, and not yet departed. Includes creators you enrolled directly and creators placed by a partner.

Query
Param Type Default Notes
limit integer 20 Max 100.
after string — Opaque cursor (forward). Pass the response's next_cursor back here.
before string — Opaque cursor (backward). Mutually exclusive with after.
Response
{
"object": "list",
"data": [
{
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe",
"avatar_url": "https://cdn.jointrybe.com/...",
"joined_at": "2025-08-12T14:23:01Z"
}
],
"has_more": true,
"next_cursor": "eyJqb2luZWRfYXQi...",
"previous_cursor": null
}

name is the creator's display name (first_name + ' ' + last_name). avatar_url is an optimized profile-photo URL (public CDN, square, up to 320px) you can embed directly, or null when the creator has no photo; re-fetch the creator rather than storing the URL, since it changes when the creator updates their photo. No PII beyond display name and photo is returned. There is no username field — usernames are intentionally not part of the v1 contract because they are mutable.

Get a creator
GET /v1/creators/{creator_id}

Returns the creator's identity plus their active program enrollments at your brand. Lookups are by stable Trybe creator id only.

Response
{
"object": "creator",
"id": "creator_8f3e21a0-...",
"name": "Jane Doe",
"avatar_url": "https://cdn.jointrybe.com/...",
"joined_at": "2025-08-12T14:23:01Z",
"programs": [
{
"id": "program_xyz789",
"name": "Spring 2026 UGC",
"enrolled_at": "2025-08-12T14:23:01Z",
"status": "active",
"commission": {
"type": "rule_based",
"display_text": "10% of GMV • $5.00 per order",
"display_rules": [
"10% of GMV",
"$5.00 per order"
]
}
}
]
}

Programs

A creator may be enrolled in multiple programs at the same brand. Each entry includes:

id, name — program identity.
enrolled_at — timestamp of the active enrollment.
status — always "active" in v1 (we only return active enrollments).
commission:
type — always "rule_based" when commission data is present.
display_text — a single human-readable summary, suitable for UI labels.
display_rules — an ordered array of human-readable summaries, one per active rule.
null if the program has no active commission rules. (This is a rare data state; if you see it for a program you expect to be configured, contact your Trybe account manager.)

Raw commission rule payloads (rule type, value, caps) are not exposed in v1. We surface only the formatted display strings, which are guaranteed to match what you see in the brand portal. Machine-readable rule data may be added in a future endpoint.

Errors
Status Type
401 invalid_api_key
403 feature_not_enabled
404 not_found — creator not found or not active for your brand
429 rate_limit_exceeded
