# /help/brand-guides/troubleshooting-attribution
Fuente: https://jointrybe.com/help/brand-guides/troubleshooting-attribution (capturado 18-sep-2026)

Troubleshooting Attribution

If you got a banner or email pointing you here, there's something to check on your account's tracking setup. This page walks you through it. Most fixes take under 10 minutes.

Why it matters

When tracking breaks, sales still happen — but your creators don't get proper credit for them. Creators who don't see results stop making content for you and might leave negative reviews.

This guide covers Trybe Attribution

Trybe Attribution is our server-side attribution model: your store sends completed orders to Trybe from its own server, and we match each one back to the creator video that drove it. Because the match happens server-side, it depends on three things staying in place — the tracking code on your ad URL, the Trybe pixel on the pages you send traffic to, and a live connection to your store (Shopify, or the Trybe pixel with the Orders API). You also need a live Meta connection to launch and sync ads through Trybe, or if a program pays on Meta attribution. Each guide below covers one of them.

How Trybe Attribution works

Every approved video gets its own tracking code. It goes at the end of your ad's website URL:

yourstore.com/products/item?trybe=a1b2c3d4

When someone clicks your ad and buys, that code tells us which creator's video drove the sale. If the code is missing, gets lost along the way, or Trybe loses connection to your store, sales stop getting credited. The three guides below cover each of those.

The Trybe ad builder does this for you

Launch your ads from Ads → Build Ads and every landing page URL is written for you — the creator's trybe= code first, then your saved UTM parameters (utm_source, utm_medium, utm_campaign, and any custom ones) appended after it. Nothing to paste, nothing to remember per creator.

Set your UTMs once under Ads → Settings → Links & Parameters and they're applied to every ad you build from then on. Most tracking problems in Guide 1 come from ads built outside this flow.

Guide 1: Missing or incorrect tracking codes

Some ads end up running without the right code on the URL. Sales from those ads don't get credited to anyone.

Why it happens
The ad was launched or duplicated in Meta Ads Manager directly. Ads Manager doesn't add the code for you. The Trybe ad builder does.
The website URL got edited and the code was dropped.
A code from one creator's video ended up on a different creator's ad. This usually happens when you duplicate an ad and swap in new media: the copy keeps the original video's code. Every video has its own code.
How to fix it

The email or banner that sent you here lists the exact ads that need fixing and the correct code for each one.

In Meta Ads Manager, open the ad.
Edit the Website URL and add the code to the end: ?trybe=XXXXXXXX — if the URL already has a ? in it, use &trybe=XXXXXXXX instead.
Publish. You don't need to relaunch the ad.

Going forward, launch ads through the Trybe ad builder and the code gets added for you automatically.

Check that it worked

Click your own live ad and look at the address bar. If you see trybe= in the URL, you're set. Sales show up in Trybe within 24 hours.

Guide 2: Traffic going to pages Trybe can't see

Your codes can be perfect, but if the traffic goes to a page Trybe isn't installed on, we can't see the sale.

Why it happens
You're running traffic to a new landing page or a subdomain.
You're split testing pages.
A redirect between the ad and your store drops the code.
How to fix it
Add the Trybe pixel to every page you send ad traffic to.
If sales happen somewhere other than your connected store, set up the Orders API so those orders reach Trybe.

Full setup steps are in Trybe Pixel and Orders API.

The rule going forward: any page you send ad traffic to gets the pixel, including new tests and new funnels.

Check that it worked

Click your own live ad like a customer would. The trybe= code should still be in the address bar on the page you land on, and again when you get to checkout. If it's there, you're set. Sales recover within 24 to 48 hours.

Guide 3: Store or Meta connection down

The connection between Trybe and your store or Meta ad account isn't active, or your store hasn't sent any data in the last 24 hours. Until it's reconnected, nothing can be tracked, no matter how good your ad setup is.

The store connection is also what unlocks Trybe attribution when you create a program: it needs a store that is actively sending data, through Shopify or the Trybe pixel. Unlocking it does not depend on your Meta connection, a completed order, or being on Shopify specifically. You still need Meta connected to launch ads. The greyed-out option tells you exactly what is missing. If it says we haven't received your first event yet, the connection is fine and it unlocks once real traffic hits a page with the pixel.

Why it happens
The Trybe app was removed from your Shopify store, or you moved to a new store.
The Trybe pixel was removed from your site, or the Orders API stopped sending orders.
Your store has had no visits or orders in the last 24 hours.
Your Meta connection expired. This happens on its own over time, or when the person who set it up changes their password or leaves your team. Ads stop syncing and Meta-attributed programs stop crediting until it's reconnected.
How to fix it
Go to the Integrations tab.
Reconnect Meta and/or your Shopify storefront, or check the pixel and Orders API are still installed.

Sales from the time the connection was down can't be recovered, so it's worth fixing this the day you see the alert.

More help

Not on Shopify? Here's how to set up tracking with the pixel and Orders API: Trybe Pixel and Orders API.

Meta integration keeps failing? It's usually a Business Manager settings issue: who has access to your page, the connected Instagram, or the linked ad account. Work through Troubleshooting Your Meta Connection before you try reconnecting again.

Check that it worked

On the Integrations tab, your Meta connection shows Active, and your store shows Connected with a green Receiving data badge. New sales appear within 24 hours.

If the store badge reads Status unavailable, that's a temporary reporting delay, not an outage — check back in a few minutes.

No matter which fix you made

Fixing your tracking starts crediting sales from that point on. Commissions from the window when tracking was broken aren't added retroactively.

Cover any missed commissions

If your creators drove sales during that window, make it right with a manual bonus:

Go to Creators and open the Programs tab.
Open the program the creator is in.
Click the gift icon on the creator's row, then Send Bonus.

To cover several creators at once, use the Send Bonuses button at the top of the program instead.

It takes a minute, and it keeps creators earning fairly and making content for you.

Still stuck?

If you followed the guide and it's still not working after 24 hours, click the "?" icon in your Trybe account and hit Chat Now. Tell us which steps you tried and we'll take it from there.
