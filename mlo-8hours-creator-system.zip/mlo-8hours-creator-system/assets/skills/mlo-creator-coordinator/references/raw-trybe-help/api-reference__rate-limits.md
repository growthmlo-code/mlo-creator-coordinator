# /help/api-reference/rate-limits
Fuente: https://jointrybe.com/help/api-reference/rate-limits (capturado 18-sep-2026)

Rate Limits

The Brand API enforces two limit tiers, both keyed by your brand:

Tier Limit Window
Burst 60 requests / minute 60-second fixed window
Sustained 5,000 requests / day 24-hour fixed window

Windows are fixed, not sliding: each window starts with your first request after the previous window expired, and ends window seconds later. Rejected (429) requests do not extend the window — once it expires, your full allowance is available again.

Submission review actions (POST …/approve, …/reject, …/request-revision) draw from a separate sustained allowance of 2,000/day instead of the shared 5,000/day — so heavy read polling can never block you from reviewing submissions. The burst limit applies to all requests equally.

If you exceed a limit, the API returns HTTP 429 with the rate_limit_exceeded error type.

Headers

Every response includes:

ratelimit-limit: 60
ratelimit-remaining: 42
ratelimit-reset: 1762345200

ratelimit-reset is a UNIX timestamp (seconds) at which the current window resets.

Two tiers apply to every call, and these headers report the one you will meet first — normally the burst tier, so ratelimit-limit reads 60. Once your daily budget runs lower than your per-minute one, the headers switch to the daily tier and ratelimit-limit reads 5000. Pace off ratelimit-remaining and you never pass either tier.

On a 429, the headers report the tier that rejected the call.

On a 429 response, the API also sets:

retry-after: 17

— the number of seconds to wait before retrying.

Handling 429

Always honor retry-after. A simple exponential-backoff client looks like:

async function callApi(path: string, attempt = 0): Promise<Response> {
const res = await fetch(`https://api.jointrybe.com/v1${path}`, {
headers: { Authorization: `Bearer ${process.env.TRYBE_API_KEY}` },
});
if (res.status === 429 && attempt < 5) {
const wait = Number(res.headers.get('retry-after') ?? 1);
await new Promise(r => setTimeout(r, wait * 1000));
return callApi(path, attempt + 1);
}
return res;
}

Pre-auth limits

If your client repeatedly sends malformed or invalid keys, the API also rate-limits the source IP (30 attempts/minute, 300/day) before doing the database lookup. This protects shared infrastructure from credential-stuffing attempts. Valid requests do not count against any IP limit.
