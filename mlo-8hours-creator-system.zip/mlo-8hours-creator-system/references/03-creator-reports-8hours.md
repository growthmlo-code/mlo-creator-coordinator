# 03 · Creator Reports 8HOURS (premium, privados)

**Live:** `https://8hours-creator-reports.pages.dev/<slug-token>/` · **Fuente:** `assets/8hours-creator-reports/` · **Skill:** `mlo-creator-report`

Report de performance **PRIVADO por creador top** (sus vídeos + métricas de negocio + comisión). Branding 8HOURS. Dark premium mobile-first (correcto para vídeo).

## URLs privadas (token por creador)
Token = `sha1(slug|SALT)[:10]`, salt `8h0urs-mlo-private-2026-k9x2`.
- `/pete-4003bd33f9/` · `/ollie-6e0570cbbf/` · `/taylor-58e145a78a/` · `/lucas-0764bf4772/` · `/ann-03a55d65c7/`
- **Overview equipo (interno, no compartir):** `/overview-c49346f0aa/`
- Root público (`/`) no lista nada. Cada creador ve solo su página.

## Secciones por creador
cover (status + totales de negocio + earnings) · **your videos** (TODOS los vídeos activos/del creador, vídeo real de Atria) · why it works (formula) · keep/push (coaching) · film these next (briefs + CTA "Shoot by") · what happens next (timeline).

## Métricas (reversa de creator-safe SOLO aquí)
Por decisión explícita de Marcel + Mathias, estos reports 1-a-1 muestran **ad spend, conversion value (GMV), ROAS, orders** + **comisión simulada 10%** ("Your earnings · Simulated · live with Trybe").
- La comisión la calcula `build_reports.py` (`comm()`, `COMMISSION_RATE=0.10`) **desde el GMV** — no hardcodear.
- Cuando Trybe esté seteado, meter rate/payout real (OJO: GMV de plataforma last-click ≠ `purchase_value` de Meta).
- ⚠️ El clasificador de **modo automático bloquea escribir spend/GMV/ROAS en la página publicada** hasta autorización explícita.

## Branding (reskin a 8HOURS, hardcodeado en `build_reports.py`)
- Fondo `--bg` **#121111** · acento `--accent` **#9F86B8** (lavanda) · glow `rgba(159,134,184,…)`.
- Fuentes: **Plus Jakarta Sans** (body) + **Playfair Display** (serif/headlines) + JetBrains Mono (labels).
- Gradientes de avatar lavanda→púrpura (#9F86B8→#6B5486); texto sobre acento #1A1222; wordmark "8HOURS · Creator Report".
- Antes era ámbar #E0A569 → reemplazado por completo.

## Archivos
- **`creators.json`** = datos (brand, updated, angle, benchmarks, shootBy, creators[]). Cada creador: slug, name, initials, role, product, status, **totals** (gmv/spend/roas/orders), **ads**[], callout, formula, keep, push, briefs. **⚠️ el real NO está en el paquete** (ver README-creators-data.md); va `creators.example.json`.
- **`build_reports.py`** = generador (genera index + 1 página por creador + overview). Branding, comisión y tokens aquí.
- **`deploy.sh`** = `build_reports.py` → `wrangler pages deploy dist --project-name=8hours-creator-reports`.

## Refresh
Weekly task (`8hours-creator-reports-weekly`, lunes 7:05): re-saca métricas de Atria (incl. negocio), reconstruye local y avisa a Marcel para publicar — **NO auto-deploya**.

## Datos
Cuenta Atria (Meta) 8hours `2974be40b9764b00bcd0c5c75878e4f7`. AOV ≈ €66. ROAS cuenta 90d ≈ 1.045x.
