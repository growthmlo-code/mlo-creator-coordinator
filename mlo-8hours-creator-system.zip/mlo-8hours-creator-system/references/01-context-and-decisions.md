# 01 · Contexto y decisiones

Cronología de lo que se construyó para 8HOURS y **por qué** (session 592d82e3, oct-2026). Cliente: Mathias (founder) / 8hours. Dirige: Marcel (M.L.O Growth).

## Origen
Mathias pidió reports para creadores (qué funciona + qué replicar) y poder pagar a top creators sobre GMV para retenerlos. Marcel definió **2 niveles**:
1. **Report premium 1-a-1** para best performers en contrato fijo.
2. **Brief general** para el resto (vía Trybe).

## Decisiones clave (en orden)
1. **Dos entregables, métricas opuestas** (regla creator-safe). El brief general NUNCA lleva spend/ROAS/GMV; los reports premium SÍ, por decisión explícita de Marcel + Mathias.
2. **Vídeos sin descargar.** Se descubrió que las URLs de Atria `cdn.tryatria.com/analytics/<acct>/<hash>.mp4` son content-hashed, sin firma → estables; reproducen remotas en `<video>` cross-origin. (Las de Meta sí caducan — por eso se lee de Atria, no de Meta.)
3. **Comisión simulada 10%** en los reports ("Your earnings · Simulated · live with Trybe"), calculada desde el GMV en `build_reports.py` (`comm()`, `COMMISSION_RATE=0.10`) — no hardcodeada. Cuando Trybe esté seteado, meter rate/payout real.
4. **Privacidad:** URL privada con token por creador (`sha1(slug|SALT)[:10]`, salt `8h0urs-mlo-private-2026-k9x2`); root público no lista nada; overview de equipo en path propio.
5. **Branding 8HOURS** en todo (sin "MLO"): near-white #FCFCFC, near-black #121111, acento lavanda #9F86B8, Plus Jakarta Sans + Playfair Display. Se capturó del look&feel de los PDFs de 8hours.
6. **Skill generalizada** `mlo-creator-report` para replicar en cualquier marca; `creator-brief` (instalada de un zip) para el brief.
7. **SOPs** en la base maestra de Notion (Creator Reports, Creator Brief, Deploy) — cruzados, con prompt listo + versión "para tontos" + skill adjunto.

## Enriquecimientos del Creator Brief (de los PDFs 8HOURS)
- **Modal de producto** en "What's selling well now": clic → pop-up con ingredientes/dosis/mecanismos + ángulos de guion (del *Product Brief · ingredient by ingredient*) + botón a la web.
- **Sección ICPs** "Who you're filming for": 3 avatares (High Performer=primary, Biohacker, Situation-Driven Seeker) del *Ideal Customer Profile*; clic → modal con who/quick-read/sleep-problem/how-to-reach + 2 anuncios de referencia. **Sin métricas €/LTV** (creator-safe).
- **Themes "villano"** (del *Content Guide*): "The missing piece" (magnesio/melatonina/proteína) + "Your coffee is spiking your cortisol" (Rise).
- **Hook families** (listicle, día 1 vs día 30, ranking, authority, controversy…).
- **Checklist**: producto en pantalla <10s · frame limpio · sin logos de otras marcas.
- **Viral concepts** (6): ranking, controversy "electrolytes are a scam", day 1 vs 30, 3AM wake-up, sleepmaxxing, authority.
- Se dejó FUERA a propósito: sección de Formats (redundante con themes) y el stat "+380% conversión" (métrica, fuera del brief general).

## Reskin de los Reports a branding 8HOURS (oct-2026)
Los reports estaban en dark premium con acento **ámbar #E0A569**. Se reskineó a la identidad 8HOURS: fondo #121111, acento lavanda #9F86B8, Plus Jakarta + Playfair, glow/gradientes lavanda, wordmark 8HOURS. Colores hardcodeados en `build_reports.py` (no en config). Se mantuvo el formato dark premium (correcto para vídeo).

## Top creators actuales
Winners (≥10 ventas 90d y ROAS ≥ cuenta 1.045x): **Pete Pastides** (Sleep, a cámara, hook 43%, top) · **Ann Keyserling** (Sleep, faceless, hook 44%) · **Taylor Willis** (Rise, faceless, hook 44%) · **Lucas Parker** (Sleep, faceless, paused) · **Ollie Morgan** (Sleep, a cámara, buen ROAS). Fuera: Mikaela Nilsson, Ollie Groombridge (ROAS < cuenta).

## Productos
8HOURS **Sleep** (Sleep & Recovery) y 8HOURS **Rise** (= tienda "Cognition & Performance", suplemento de mañana sin estimulantes).

## Aprendizajes técnicos
- HTML estático en Cloudflare necesita `<meta charset="utf-8">` o emojis/×/·/→/€ salen mojibake.
- `content.js` del brief cachea agresivo (sin `?v=`): al redeployar, repeat-visitors pueden ver copia stale hasta refrescar; fresh visitors OK.
- El clasificador de modo automático **bloquea escribir spend/GMV/ROAS en páginas publicadas** hasta autorización explícita del usuario.
- Deploy Cloudflare puede dar 522 unos segundos en el primer deploy (propagación de dominio) → reintentar.
