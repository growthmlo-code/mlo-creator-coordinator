# 04 · SOP · Mensaje de bienvenida en el canal GMV Ads (Slack)

Añadido al **Playbook Creator Coordinator → Módulo 3 (El flujo operativo MLO) → §3.10 Onboarding del cliente**, junto al SOP del email de bienvenida.
Notion: https://app.notion.com/p/3aa6c9977eb781e6b71bca4bb44ed53e

**Objetivo:** dar la bienvenida al cliente en el canal de Slack Connect del programa (GMV Ads), dejar claro qué se gestiona ahí y pedir los inputs que ayudan a avanzar antes del kickoff, dejando ver qué preparará MLO.
**Cuándo:** justo tras crear el canal GMV Ads (Slack Connect), con el contrato firmado. Es el **primer mensaje del canal**; complementa al email de bienvenida/reserva del kickoff.
**Responsable:** Creator Coordinator prepara y personaliza; Marcel revisa antes de publicar.
**Cómo personalizar:** única variable `[Brand]`/`[Marca]`. **MUTO y 8hours: inglés. Otras marcas: castellano.** Los inputs son para revisar en la call, no un cuestionario. Revisa canal y destinatarios antes de publicar.

---

## Template · Inglés · Copiar y pegar

Hey team! 👋

Welcome to the GMV Ads channel — this is where we'll manage everything related to Creators for [Brand].

A few things that would help us keep moving before our call (we'll also cover these together on the call):

1. The list of creators who've collaborated with the brand over the last months — if you could reshare the Excel.
2. The unit economics of the new offer.
3. Any relevant brand docs you can re-share with us (ideally the most up-to-date versions — we think there are quite a few).
4. All the docs + contracts shared with the creators (plus any extra info that's relevant for us).
5. Who's in charge of managing orders and logistics with creators / ambassadors today.

With that — and together on the call — we'll be prepping:

1. Trybe set-up
2. The Creator Brief doc
3. The Report draft for creators
4. The unit economics for the GMV commission, so we can align together
5. Creating and setting up the first program

Once that's done and fully approved on your end, we'll kick off the outreach + start inviting the existing creators from our list who are interested.

Looking forward to getting this going!

Cheers,
Marcel

---

## Template · Castellano · Copiar y pegar

¡Hola equipo! 👋

Bienvenidos al canal de GMV Ads — aquí gestionaremos todo lo relacionado con los creadores de [Marca].

Algunas cosas que nos ayudarían a seguir avanzando antes de la call (también las repasaremos juntos en la llamada):

1. La lista de creadores que han colaborado con la marca en los últimos meses — si nos podéis reenviar el Excel.
2. Los unit economics de la nueva oferta.
3. Cualquier documento relevante de marca que nos podáis reenviar (a ser posible las versiones más actualizadas — creemos que hay unos cuantos).
4. Todos los documentos + contratos compartidos con los creadores (más cualquier info adicional que nos sea relevante).
5. Quién se encarga hoy de gestionar los pedidos y la logística con creadores / embajadores.

Con eso — y junto con la call — iremos preparando:

1. El set-up de Trybe
2. El doc del Creator Brief
3. El borrador del Report para creadores
4. Los unit economics para la comisión de GMV, para alinearlo juntos
5. Crear y montar el primer programa

Una vez esté hecho y aprobado por vuestra parte, arrancamos con el outreach + empezamos a invitar a los creadores que ya tengáis en la lista y estén interesados.

¡Con muchas ganas de ponerlo en marcha!

Un saludo,
Marcel
