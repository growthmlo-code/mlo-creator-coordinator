# 05 · Skills implicadas

Las 3 skills que mueven este sistema. Copias completas en `assets/skills/`. En local viven en `~/.claude/skills/`.

## `creator-brief`
Genera el **brief/deck web** que el creador abre en el móvil (sube a Trybe, no postea). Sin métricas.
- Flujo: intake (4 rondas) → winning ads → `scripts/build_brief.py brief.json` → carpeta estática (index.html + content.js + media).
- Renderer: `assets/index.html` (Plus Jakarta Sans, theme {ink,paper,accent}→`--gold`). Para 8HOURS se usa un renderer custom (`renderer-8hours.html`) copiado sobre el build.
- Reglas duras: nada inventado; nada de métricas/payouts en la página; sin nombres de creador (captions = producto); vídeos como embeds (no se descargan).
- Entrada de la sesión: marca 8hours, cuenta Meta ya conectada en Atria, entrega hosteada.

## `mlo-creator-report`
Generaliza los **reports de performance privados por creador** (vídeos Atria + GMV/ROAS/orders + comisión).
- `assets/build_reports.py` (generador) + `assets/creators.example.json` (plantilla) + `references/` (data-pipeline, build-deploy, best-practices).
- Config vía bloque en `creators.json`: brand, accent, commissionRate, salt, benchmarks.
- URLs privadas con token; overview de equipo en path propio. **La regla de métricas (best-practices.md) es lo más importante.**

## `mlo-creator-coordinator`
Agente/knowledge-base del **Creator Coordinator** de MLO: gestiona y escala creadores UGC/afiliados para las marcas DTC.
- `references/` (playbook operativo, sistema Notion, contratos y compensación, Trybe y plataformas + API, modelos de comisión, sourcing, legal EU, scaling economics, servicio CGP, perlas de calls) + `templates/` (outreach, cuestionario, oferta, prelista, call semanal, reporte, propuesta de servicio) + `scripts/trybe_api.py`.
- Trybe = `jointrybe.com` (≠ TRIBE). Contratos A/B/C. Comisión creadores 15% GMV (modelo CGP vigente).
- El **Playbook Creator Coordinator — De 0 a 100** vive en Notion (Company SOP & PlayBooks Hub); el SOP del mensaje de bienvenida GMV Ads se añadió en su Módulo 3 §3.10.

## SOPs relacionados (Notion, base maestra)
- **SOP — Creator Performance Reports** (report privado por creador, CON métricas) → skill `mlo-creator-report`.
- **SOP — Creator Brief** (onboarding, sin métricas) → skill `creator-brief`.
- **SOP — Deploy** (subir brief/report a Netlify/Cloudflare + Claude Code).
- Los tres cruzados, con prompt listo + versión "para tontos" + skill adjunto.
