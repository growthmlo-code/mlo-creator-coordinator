# 02 · Creator Brief 8HOURS

**Live:** https://8hours-creator-brief.pages.dev · **Fuente:** `assets/8hours-creator-brief/` · **Skill:** `creator-brief`

Deck web de una página que el creador abre en el móvil (sube a Trybe, no postea). **1 idioma (EN)** — la tienda vende a 43 países pero solo en inglés. **Sin métricas, sin comisiones, sin contacto.**

## Las 10 secciones (índice numerado)
1. **Vibe & Style**
2. **Example shots** (frames reales de ads)
3. **What's selling well now** — 2 productos (Sleep & Recovery, Cognition & Performance/Rise) con **modal de producto**
4. **Who you're filming for** (ICPs) — 3 avatares con **modal**
5. **Themes that sell right now** — 9 temas (incl. 2 "villano")
6. **Viral concepts to try** — 6 conceptos trend/format
7. **What you can say / never say**
8. **5 content principles**
9. **Hooks — how to start** (+ hook families + frames + lines)
10. **Checklist** (do / don't)

## Arquitectura de archivos
- **`brief.json`** = todo el contenido. Bloques top-level: `theme` (ink/paper/accent), `topVideos`, `hookFrames`, `bestSellers` (con `details` por producto para el modal), `icps`, `viral`, y `langs.en` (vibe, frames, bestsellers, icps, viral, themes, claims, principles, hooks, checklist, footer).
- **`renderer-8hours.html`** = renderer custom con el look&feel de 8HOURS (copia del `index.html` del skill + overrides CSS). `deploy.sh` lo copia sobre el `index.html` construido.
- **`deploy.sh`** = corre `build_brief.py` del skill → copia el renderer custom → `wrangler pages deploy`.

## El modal genérico (`fillModal`)
Un único modal `#bsModal` sirve a **productos** y **avatares** (campos opcionales: when, name, tag, summary, list1/2/3, ingredients, refAds, cta). El grid de bestsellers y el grid de ICPs enganchan clicks que llaman `openProduct()` / `openAvatar()` → `fillModal()`.
- **Producto:** ingredientes (nombre/dosis/línea) + ángulos + CTA "View on 8-hours.com". Contenido del *Product Brief · ingredient by ingredient*.
- **Avatar:** who + quick-read + sleep-problem + how-to-reach + 2 anuncios de referencia (posters Atria → mp4). Sin CTA.
- Gotcha resuelto: `.btn{display:inline-flex}` gana al atributo `hidden` → al ocultar el CTA hay que forzar `style.display='none'`.

## Branding (overrides en el renderer)
- Fondo near-white #FCFCFC, texto near-black #121111, acento `--gold` = lavanda **#9F86B8** (se setea desde `theme.accent`).
- **Títulos** en Plus Jakarta Sans (sans); **subtítulos** (.lede/.sub) en Playfair Display (serif). *(Marcel prefirió los títulos en sans.)*
- Blob de gradiente lavanda arriba-derecha en cada slide (como los PDFs).

## Deploy
```bash
bash ~/claude/8hours-creator-brief/deploy.sh
```
Gotcha: `content.js` sin `?v=` cachea fuerte → fresh visitors ven la última; repeat-visitors pueden necesitar refresh. El build inyecta `<meta charset="utf-8">`.

## Refresh
Manual (`bash deploy.sh`) o pedirlo. El weekly auto-update quedó **bloqueado** por el clasificador de modo automático (no deja cron desatendido que auto-publica a web).
