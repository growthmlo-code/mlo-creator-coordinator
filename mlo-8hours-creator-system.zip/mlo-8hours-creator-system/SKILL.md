---
name: mlo-8hours-creator-system
description: >-
  Paquete de conocimiento del sistema creator-facing de 8HOURS (M.L.O Growth):
  Creator Brief general (Trybe, sin métricas) + Creator Reports privados por creador
  (con métricas + comisión), ambos en Cloudflare Pages con datos reales de Atria.
  Incluye la conversación entera de la sesión, el contexto y las decisiones, las skills
  implicadas (creator-brief, mlo-creator-report, mlo-creator-coordinator) y las fuentes
  de ambos entregables. Úsalo para replicar el sistema en otra marca o retomar el de 8HOURS.
metadata:
  type: reference
  brand: 8HOURS
  agency: M.L.O Growth
  session: 592d82e3
  created: 2026-10-07
---

# mlo-8hours-creator-system

Snapshot completo de todo lo construido para el **sistema creator-facing de 8HOURS** durante la sesión del 7-oct-2026, empaquetado como skill para subir a GitHub. Contiene la **conversación entera**, el **contexto y las decisiones**, las **skills implicadas** y las **fuentes** de los dos entregables web.

> **Para qué sirve:** retomar el sistema de 8HOURS, auditar qué/por qué se hizo, o **replicarlo en otra marca** (MUTO es el siguiente). No es una skill ejecutable: es un paquete de referencia + assets.

## Qué hay en vivo (producción)

| Entregable | URL | Métricas | Para quién |
|---|---|---|---|
| **Creator Brief** (general) | https://8hours-creator-brief.pages.dev | ❌ sin métricas | TODOS los creadores (Trybe) |
| **Creator Reports** (premium) | `…pages.dev/<slug-token>/` (privados) | ✅ spend/GMV/ROAS/orders + comisión 10% | Best performers en contrato fijo |
| **Overview equipo** (interno) | `…8hours-creator-reports.pages.dev/overview-c49346f0aa/` | ✅ | Solo MLO (no compartir) |

Reports privados: `/pete-4003bd33f9/` · `/ollie-6e0570cbbf/` · `/taylor-58e145a78a/` · `/lucas-0764bf4772/` · `/ann-03a55d65c7/`

## La regla de oro (creator-safe)

Dos entregables, métricas opuestas:
- **Creator Brief** = onboarding para todos → **NUNCA** spend/ROAS/GMV/earnings.
- **Creator Reports** = 1-a-1 para top creators en contrato → **SÍ** métricas de negocio + comisión, por decisión explícita del cliente (pagan sobre GMV y quieren transparencia).

Nunca mezclar. El brief general se mantiene limpio siempre.

## Arquitectura en 10 líneas

- **Datos reales de Atria** (MCP), cuenta Meta 8hours `2974be40b9764b00bcd0c5c75878e4f7`. Vídeos vía URLs `cdn.tryatria.com/...mp4` **content-hashed, estables, sin descargar** (reproducen remotas cross-origin).
- **Creator Brief:** skill `creator-brief` → `brief.json` (contenido) + `renderer-8hours.html` (look&feel 8HOURS: near-white #FCFCFC, near-black #121111, acento lavanda #9F86B8, Plus Jakarta + Playfair) → `deploy.sh` → Cloudflare.
- **Creator Reports:** skill `mlo-creator-report` → `creators.json` (datos) + `build_reports.py` (generador, comisión 10% calculada desde GMV) → URLs privadas con token `sha1(slug|SALT)[:10]` → Cloudflare.
- **Deploy:** `npx wrangler pages deploy <dir> --project-name=<p> --branch=main --commit-dirty=true` (cuenta growth.mlo@gmail.com).
- **HTML estático necesita `<meta charset="utf-8">`** o salen mojibake.

## Contenido del paquete

```
mlo-8hours-creator-system/
├── SKILL.md                      ← este archivo
├── CONVERSATION.md               ← la conversación ENTERA (183 mensajes de Marcel + respuestas + acciones)
├── references/
│   ├── 01-context-and-decisions.md   ← qué se construyó y por qué (cronología de decisiones)
│   ├── 02-creator-brief-8hours.md    ← el brief: 10 secciones, modelo de datos, modales, deploy
│   ├── 03-creator-reports-8hours.md  ← los reports: branding, métricas, comisión, privacidad
│   ├── 04-gmv-ads-welcome-sop.md     ← SOP mensaje de bienvenida canal GMV Ads (EN + ES)
│   └── 05-skills-involved.md         ← las 3 skills y dónde viven
└── assets/
    ├── 8hours-creator-brief/     ← brief.json · renderer-8hours.html · deploy.sh (sin métricas, seguro)
    ├── 8hours-creator-reports/   ← build_reports.py · deploy.sh · creators.example.json (SANITIZADO)
    └── skills/                   ← creator-brief · mlo-creator-report · mlo-creator-coordinator (copias)
```

## ⚠️ Privacidad — leer antes de subir a GitHub

- El **`creators.json` real** (nombres de creadores + GMV/spend/ROAS/orders reales + comisión) **NO está incluido**. En su lugar va `creators.example.json` (datos ficticios). El real vive solo en local. Si quieres incluirlo, **usa un repo PRIVADO**.
- Las URLs de los reports son **privadas por token** — no las publiques en un README público.
- Las skills incluyen conocimiento interno de MLO (contratos, economía, calls). Mantén el repo privado salvo que decidas lo contrario.

## Cómo replicar en otra marca (p. ej. MUTO)

1. Lee `references/02` y `03`.
2. Duplica `assets/8hours-creator-brief/` → cambia `brief.json` (contenido de la nueva marca) y el acento/branding en `renderer`.
3. Duplica `assets/8hours-creator-reports/` → crea `creators.json` desde `creators.example.json` con datos reales de Atria.
4. Usa las skills `creator-brief` y `mlo-creator-report` (en `assets/skills/`) como motor.
5. Deploy a Cloudflare con `deploy.sh` (cambia el `--project-name`).
