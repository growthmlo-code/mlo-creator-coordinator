# mlo-8hours-creator-system

Paquete de conocimiento (tipo skill) del **sistema creator-facing de 8HOURS** de M.L.O Growth: Creator Brief general + Creator Reports privados por creador, ambos en Cloudflare Pages con datos reales de Atria. Incluye la **conversación entera** de la sesión, el contexto y las decisiones, las skills implicadas y las fuentes de ambos entregables.

👉 **Empieza por [`SKILL.md`](./SKILL.md).**

- La conversación completa: [`CONVERSATION.md`](./CONVERSATION.md)
- Contexto y decisiones: [`references/01-context-and-decisions.md`](./references/01-context-and-decisions.md)
- Creator Brief: [`references/02-creator-brief-8hours.md`](./references/02-creator-brief-8hours.md)
- Creator Reports: [`references/03-creator-reports-8hours.md`](./references/03-creator-reports-8hours.md)
- SOP bienvenida GMV Ads (EN/ES): [`references/04-gmv-ads-welcome-sop.md`](./references/04-gmv-ads-welcome-sop.md)
- Skills implicadas: [`references/05-skills-involved.md`](./references/05-skills-involved.md)

## ⚠️ Privacidad
El `creators.json` real (nombres + GMV/spend/ROAS/orders reales) **NO está incluido** — va la plantilla `creators.example.json`. Las URLs de reports son privadas por token. Mantén el repo **privado** salvo que decidas lo contrario.
