# Selection rules — turning the user's files into deck content

These rules decide what goes on the page. Apply them, show the picks to the user (intake gate), then build. Winning ads come from the user or, with their permission, from the ad account. Never ask the user to type performance numbers, and no metric ever appears on the page.

## Winning ads from the ad account (intake Q7, permission given)
- **Window:** last 90 days, ad level. Also pull the last 30 days to show recency at the gate.
- **Purchases:** count exactly one action type — `omni_purchase` (fall back to `purchase`). Meta repeats the same sales under several types; summing them inflates ROAS several times over.
- **Videos only.** Resolve every ad to its video ID, including existing-post ads (the creative points at a page post — check whether the post is a video). Static images are out.
- **Same video, several ads:** group by video ID and sum spend, purchases and value.
- **Rule:** at least 10 purchases in 90 days and ROAS (value ÷ spend) at or above the account's 90-day ROAS; rank by purchases. Take the top 10–15 to the gate.
- **Download** each pick's mp4 straight away (source URLs expire within hours), then compress as below.
- **Creator names:** ad names rarely carry them. At the gate, ask the user for the first names, or caption with the product only.

## Top videos → `topVideos` (section "Example shots")
- **Source:** the winning ads (intake Q7) — the user's order, or the ranking above.
- **How many:** 5–10. Variety beats ten videos from one person: if the same creator appears in more than two, keep their two best-ranked.
- **Same video twice:** the same video uploaded twice (e.g. into two ad sets) counts once.
- **Files:**
  - Compress each one: `scripts/media.py compress <file> media/videos`. This gives a 720 px, light mp4 and a poster.
  - Links work too: TikTok `tiktok.com/@user/video/<id>` (not `vm.tiktok.com`), an Instagram reel, or YouTube Shorts. `media.py` can download a public post URL when yt-dlp is installed. That is the way to get videos posted on a creator's own page.
  - Drive links play in Drive's player with an "open in Drive" button. A local mp4 is cleaner.
  - Run `media.py probe` and flag anything below 540 px wide to the user: it will look soft on a phone.
- **Caption:** the product, if known. No creator names.

## Opening frames → `hookFrames` (section "Hooks")
- **Source:** the same winning ads, in the same order (the user's order, or the ad-account ranking). Up to ~10, one per video. Never ask the user for screenshots.
- **Frame:** `scripts/media.py frame <video> media/hooks/NN.jpg`. Taken at 0.4 s, 720 px wide, from the video itself. Ad platforms' thumbnails are tiny and useless here.
- **Caption:** the product, if known. No creator names.

## Competitor reference ads → `referenceAds`
- **Source:** Meta Ad Library, filtered to the market's country and active ads. "Started running on" gives the days running.
- **Rank:** by days running, top 10. Two variants of the same creative are fine, but say so in the headline, e.g. "(variant)".
- **Link:** `https://www.facebook.com/ads/library/?id=<ad id>` (strip any prefix such as `facebook_` from exported IDs).
- **Headline:** the ad's own headline. When the brief has several languages, give `{ "<market lang>": original, "en": translation }`.
- Ten ads from only two brands is a real finding. Show it as it is, don't pad the list with weaker brands.

## Products to recommend → `bestSellers.<lang>`
- **First choice: the user's list** (intake Q10). Use it as given, in their order and split.
- **No list → the store's own sales ranking**, shown at the gate:
- **Shopify:** `https://<store>/collections/all?sort_by=best-selling` is the store's own sales ranking. Two traps:
  1. Read product links only inside the main product grid. Featured strips above it repeat the same products on every collection page and invent a ranking.
  2. Don't rank inside curated collections ("men", "women", seasonal). They are hand-picked and miss real top sellers. Rank the whole store, then split by the store's own product type or tags. Never guess the segment from a product name.
- **Details:** `/products/<handle>.json` gives the title and first image (add `?width=320` to Shopify CDN image URLs).
- **WooCommerce:** `https://<store>/<category-or-shop-page>/?orderby=popularity` sorts by total sales. Same traps: read only the main product grid (`ul.products`), and rank the right category (e.g. only the product line the brief is about). The page may sit behind a bot check — load it in a real browser (Playwright).
- **Other platforms:** ask the user for the list from the store's analytics.
- **Filter:** drop bundles, gift cards, samples, mystery boxes and freebies.
- **How many:** top 5 per group (e.g. For him / For her / New).
- **Titles:** exactly as the store writes them. A recurring prefix ("Inspired by…") goes in `pre`.
- **One block per language** (labels in that language). Each language points at the store that sells to it.

## Themes → `langs.<code>.themes.items`
- **Source: only ads running and performing now.** From the winning ads, keep those with spend in the last 30 days, at least 5 purchases in that window and 30-day ROAS at or above the account's 30-day ROAS (one purchase type, as above). With user-supplied ads, ask which ones are running now.
- **Read every ad:** transcribe and watch it (Gemini video breakdown or your own viewing): where it's filmed, the everyday moment, how the story is told, the opening line and on-screen text.
- **Group by story format** (e.g. durability test, comparison with drugstore nails, one-year testimonial, list of mistakes). 3–5 themes.
- **Each theme lists:**
  - `setting` — where and in what moment (e.g. "at the desk during a beauty routine", "in the car before work");
  - `format` — how the video tells the story, beat by beat, short;
  - `hooks` — 2–3 opening lines taken from those ads, lightly smoothed so a creator can say them;
  - `frames` — the opening frames (from `hookFrames`) of the ads in this theme.
- **Prices:** in each market's currency, from that store.
- **USPs:** only from the user's list.

## Hook lines → `langs.<code>.hooks.lines`
- **Source:** the opening sentence of the winning ads (transcripts), rewritten so a creator can say it naturally.
- **How many:** 5–8, each a different angle, in the creator's language.
- **Framing:** they are inspiration, not a script. The intro tells creators to say them in their own words.

## USPs → `langs.<code>.claims`
- `items`: the unique selling points the user wants highlighted (intake Q13), as they gave them. A proof, if any, stays in your notes.
- `never`: the user's banned words, plus legal terms where they apply (e.g. "copy", "replica", "fake" for inspired-by products; medical promises for cosmetics or supplements). No list from the user → leave `never` out.
- No brand rules: don't ask about other brands and don't add a "never mention brand X" item.

## Privacy and hygiene
- No creator names, payouts, metrics or internal notes on the page.
- `build_brief.py` copies only the files brief.json references, so working files in the media folder never reach the published folder.
- Translations without a native proofread get flagged to the user by language.

## Refresh cadence (tell the user at delivery)
- **Weekly:** themes, best sellers, opening frames.
- **Monthly:** top videos, competitor ads.
- Re-run `build_brief.py` after each change. It changes the cache version, so creators see the new copy.
