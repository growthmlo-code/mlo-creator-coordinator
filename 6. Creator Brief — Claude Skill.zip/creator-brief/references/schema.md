# brief.json — schema

`build_brief.py` turns this file into `content.js` (`window.BRIEF = …`). The renderer (`assets/index.html`) reads it. A complete working example: `assets/brief.example.json`.

**Text values.** Any text can be:
- a plain string, in the language of the block it sits in; or
- an object keyed by language, `{ "en": "…", "sv": "…" }`. Use this for shared items such as captions and competitor headlines.

**Tokens.** Replaced per market at render:

| Token | Becomes |
|---|---|
| `{brand}` | brand name |
| `{brandTitle}` | hero headline |
| `{contact}` | creator contact |
| `{store}` | store domain (only in `bestsellers.note`) |

Square brackets, TBD and TODO fail the build. That is deliberate: no placeholder ever reaches a creator.

**Empty or missing section = hidden**, heading included. Section numbers close up automatically.

## Top level

| Key | Required | What |
|---|---|---|
| `id` | – | Short slug, used for the output folder and the browser memory of the chosen market |
| `brand` | yes | Brand name (page title, fallback) |
| `theme` | – | `{ "ink": "#0F172A", "paper": "#F7F7F7", "accent": "#C8A96A" }` — dark slides/text, light background, numbers/buttons |
| `brands` | yes | `{ key: { name, title, mark, contact } }` — one entry, or one per brand when markets sell under different names |
| `countries` | when >1 market | `[ { id: "SE", flag: "🇸🇪", name: "Sverige", lang: "sv", brand: "main" } ]` — picker entries; `id` is the deep link `?c=SE`. One entry = no picker |
| `popup` | – | Picker texts `{ eyebrow, title, sub }` (shown before a language is chosen, so write them in English or the main language) |
| `topVideos` | – | `[ { url, title: "Cedar & Smoke", poster } ]` — section "Example shots". `title` = the product, if known (no creator names; empty = no caption). `url` = local mp4 (`media/videos/x.mp4`) or a TikTok/IG/YouTube link |
| `frames` | – | Still screenshots: `[ { src, caption } ]` |
| `referenceAds` | – | `[ { brand, days, url, headline } ]` — longest-running competitor ads |
| `hookFrames` | – | `[ { src, product } ]` — opening frames of the best ads; `product` is the caption (optional, no creator names) |
| `examples` | – | `{ faceless: [ {url, title} ], spoken: [ … ] }` — example videos/links in "Hooks" |
| `bestSellers` | – | Keyed by language: `{ "en": { store, groups: [ { label, items: [ { name, pre, url, img } ] } ] } }` |
| `langs` | yes | Keyed by language code, all copy (below) |

## Per language: `langs.<code>`

| Key | Shape |
|---|---|
| `name` | Language name shown on the picker button ("English", "Svenska") |
| `ui` | `{ soundOn, soundOff, open }` — video button labels (default English) |
| `hero` | `{ kicker, title, tagline, indexTitle }` — `title` usually `"{brandTitle}"`; last word renders in the accent colour |
| `vibe` | `{ title, items: [ { title, body } ] }` |
| `frames` | `{ title, note, swipe, videos?, stills?, refs? }` — `videos` overrides `topVideos` for this language; `stills: false` hides `frames`; `refs: { title, note, daysWord }` turns on the competitor list |
| `bestsellers` | `{ title, note }` — the products themselves live in top-level `bestSellers[code]` |
| `themes` | `{ title, note, labels: { setting, format, hooks }, items: [ { title, setting, format, hooks: [ "…" ], frames: [ "media/hooks/01.jpg" ], body? } ] }` — one card per theme: setting + story format + hook lines + the opening frames of the ads behind it. Items with only `{ title, body }` render as plain cards |
| `claims` | `{ title, intro, sayTitle, items: [ "…" ], neverTitle, never: [ "…" ] }` |
| `principles` | `{ title, items: [ { title, body, list? } ] }` |
| `hooks` | `{ title, intro, framesTitle, framesNote, linesTitle, lines: [ "…" ], faceless, spoken }` — a group shows only when its title and its content both exist |
| `examples` | Optional per-language override of top-level `examples` |
| `checklist` | `{ title, doTitle, dontTitle, dos: [ … ], donts: [ … ] }` |
| `results` | `{ title, intro, items: [ { title, body } ] }` |
| `footer` | `{ title, note, cta: { label, url }, contact?, switchLang }` — closing slide = call to action: title, the next step, a button to the upload link (hidden without `url`), optional contact line. Always set `title`; without it the slide falls back to the hero tagline |

## Deck order (fixed)

1. Hero (with index)
2. Vibe & style
3. Example shots
4. What's selling
5. Themes
6. What you can say
7. Principles
8. Hooks
9. Checklist
10. After you upload
11. Closing

There is no posting section: creators upload to the commission platform, they don't post on their own accounts.

## Media paths

Local paths are relative to the media root (default: the folder brief.json is in), e.g. `media/videos/anna.mp4`. The build copies only the files brief.json references into the output, keeping the same relative paths. Working files in the media folder never get published.
