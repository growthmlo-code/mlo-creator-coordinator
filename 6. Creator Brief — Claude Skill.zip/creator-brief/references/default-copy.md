# Default copy (English master)

Proven copy for the sections that are the same for every brand. Adapt it to the product category: swap "perfume" for the user's product, and use the places and moments where that product is really used. Keep the meaning. Keep it plain: short sentences, no sales talk. That is the same standard the brief asks of creators.

Sections that come from the brand's data (example shots, best sellers, themes, hook lines, claims) have no default text here. Only their headings and notes do. No data means the section stays out.

Write the master language first and get the user's approval. Then translate. Keep `{tokens}` untouched. Put prices in each market's own currency, taken from that store — never converted by guess.

---

## hero
- kicker: `Creator Brief`
- title: `{brandTitle}`
- tagline: `What good creator content looks like`

## vibe — title `Vibe & Style`
1. **Natural, calm pace** — Not too fast, not too slow. The viewer has time to follow.
2. **Starts with a real moment** — The first shot stays the same for 4 seconds: like a friend just pulled out their phone.
3. **The same calm setting** — Through the whole video: [the 3–4 everyday places where the product is used].
4. **Looks organic, not produced** — No "incredible results", no "you need this", no "buy now" energy.
5. **Easy to watch** — So it doesn't feel like an ad: you just want to know how the story ends.
6. **Follows the person** — No rush. The viewer stays with you.

## frames
- title: `Example shots`
- note: `Real videos from our ads. Look at the framing and the style.`
- swipe: `Swipe for more →`
- refs.title: `Longest-running ads`
- refs.note: `Competitor ads that have run the longest in your market. Open them in Meta's Ad Library and look at how they are built – not at the product.`
- refs.daysWord: `days`

## bestsellers
- title: `What's selling well now`
- note: `You can choose one of these if you want to increase your chances.`

## themes
- title: `Themes that sell right now`

## claims
- title: `What you can say`
- intro: `Pick 1–2 points that fit your hook and say them in your own words.`
- sayTitle: `You can say` · neverTitle: `Never say`

## principles — title `5 content principles`
1. **Real places: authenticity > perfection** — Real places only. Where you use [product] in everyday life. Authenticity builds trust.
2. **You tell the story** — The product is part of an everyday story. The viewer sees exactly when and why they would use it themselves. No selling: just a moment the viewer recognises from their own life.
3. **Low barrier** — Every format has a setting you recognise instantly. Within 1–2 seconds the viewer knows what kind of video this is: no explaining, no patience needed. The format itself is the promise.
4. **Feeling before information** — Start with the moment, not the product. Show the problem, the habit, the feeling: give viewers a reason to care. The product should become the obvious answer.
5. **A built-in reason to keep watching** — list: `Get ready with me = curiosity.` · `[Product] test = a verdict is coming.` · `Challenge: [can you tell which is which?] = suspense.` · `Routine = a familiar ritual.` — body: `Every format has a mechanism that creates momentum without forcing it. We just want to know what happens next.`

Adapt the formats in principle 5 to the category, e.g. skincare: "before/after the night routine"; coffee: "morning ritual".

## hooks
- title: `Hooks — how to start`
- framesTitle: `How our best-performing ads open`
- framesNote: `Real first frames from ads that are running right now.`
- linesTitle: `Lines you can open with`
- faceless: `Faceless` · spoken: `Talking to camera`

## checklist — title `Checklist`, doTitle `Do`, dontTitle `Don't`
Do:
- Text visible in the first second of the video, with the hook fully readable
- Natural pace: not too fast, not too slow
- First 4 seconds: one shot, no cuts
- Familiar, natural places: [places]
- No sales talk: no "you need this", no "buy now"
- Easy to watch: feels like a story, not an ad
- Follows the person: no rush
- Organic format, recognisable within 1–2 seconds
- Starts with a moment, not a product
- Momentum built into the format's structure

Don't:
- Staged or tidied-up setting
- Opens with a product promise
- Sales talk or urgency triggers
- Scripted or produced feel
- Format unclear in the first 2 seconds

## results — title `After you upload: sales and ads`, intro `What happens after you upload your video to [platform] – and how your commission is counted.`
Fill from intake Q5 (platform, commission, payout schedule, launch cadence). Drop any item the user didn't answer. Tracking is fixed text (platform link, last click) — never ask about it. Creators only upload to the platform — never add steps about posting on their own accounts.
1. **How your sales are tracked** — Every ad with your video links to our store through your personal [platform] link. When someone clicks the ad and buys, the sale is credited to you on last click: the purchase goes to the last creator link the buyer clicked before checkout.
2. **When a sale is registered** — The sale is registered when the order is placed at checkout. Refunded or cancelled orders don't count. You earn [commission] of the order value, paid out [schedule].
3. **What we do after you upload** — [Cadence] we pick up newly uploaded videos, launch them as ads and review the ads already running. Ads that bring us new customers get more budget – and earn you more commission.
4. **How budget is spread across ads** — The ad platform decides where most of the budget goes. It predicts which ad will perform best and spends there. We adjust budgets by hand as well.

The [brackets] above are slots for you to fill from the intake. The build fails while any bracket is left.

## footer — the closing slide is a call to action, never a repeat of the tagline
- title: `Your turn`
- note: `Pick a theme, film your video and upload it in [platform].`
- cta: `{ "label": "Open [platform]", "url": "<upload link from intake Q5>" }` — no link = no button
- contact (only when there is a contact): `Questions? Message {contact}.`
- switchLang: `Change language`

## popup (only with more than one market)
- eyebrow `Creator Brief` · title `Where are you from?` · sub `Pick your country — we'll show the brief in your language.`
