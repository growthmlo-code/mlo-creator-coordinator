# Intake — what to ask, in four rounds

Send one round per message, numbered, so the user can answer in one go. Each question says what it feeds, so the user knows why you need it. Files are welcome at every step: winning ad videos, screenshots, store exports, transcripts, old briefs, brand guidelines.

The user can answer "skip" to anything except Round 1, the winning ads (Q7) and hook lines (Q12). A skipped item means that section is hidden in the deck (heading included). Never fill it with a guess or a "coming soon" box. Keep a running list of what is hidden and report it at the end.

If the user dumps files before you ask, read them first and only ask for what is still missing.

Creators upload their videos to the commission platform (e.g. Trybe). They don't post on their own accounts, so the brief has no posting steps — don't ask about posting, handles or tagging.

---

## Round 1 — Basics (required)

1. **Brand name** as creators should see it. A different wordmark for the top bar? (Optional.)
2. **Product category**, and what a creator receives to film (e.g. "two 50 ml perfumes", "starter kit").
3. **Markets:** country → language → store link. One market means no country picker.
4. **Creator contact:** name and channel (e.g. "Anna, WhatsApp"), or "your contact at {brand}". "None" is a valid answer: the closing slide then has no contact line.
5. **Commission setup** → "After you upload" section:
   - platform creators upload their videos to (e.g. Trybe), and the link they open to upload — it becomes the button on the closing slide (optional; no link = no button);
   - commission (e.g. 15% of GMV) and payout schedule;
   - how often you launch new videos as ads (e.g. twice a week).

   Don't ask about tracking or attribution. The platform's creator link credits sales on last click; that text is fixed in default-copy.md.
6. **Brand colours:** dark, light, accent (hex), or a brand-guidelines file. Optional; there is a default palette.

## Round 2 — Proof (files)

7. **Winning creator ads (required)** → top videos + opening frames on the Hooks slide. Two ways, the user picks one:
   - **Supply them:** 5–10 videos as mp4 files or public post links (TikTok `tiktok.com/@user/video/<id>`, Instagram reel, YouTube Shorts), each with the product shown. Don't ask for creator names; the deck doesn't show them.
   - **Permission to pull them from the ad account:** the account ID. You pull the top performers by the rule in selection-rules.md and download the videos. You need a Meta Ads tool (MCP or API) for this; without one, ask for the files.

   The opening frames are taken from these videos — never ask for screenshots. Never ask the user to type performance numbers.
8. **Optional: competitor ads** that have run longest in the market — Ad Library links, or just competitor names (you look them up). Ask once; no answer = the list stays off.
9. **Optional:** creator videos the user likes for their style, split into faceless vs talking to camera. They go to the examples in Hooks.

## Round 3 — What sells, what to say

10. **Products to recommend** → "What's selling now". Ask which products the brand wants creators to pick (a list or a file), per market, and how to split them (e.g. by shape, by category). No list → take the store's own sales ranking (selection-rules.md) and show it at the gate.
11. **Themes — nothing to ask.** You build them from the winning ads that are running and performing now (selection-rules.md): setting, story format, hook lines and frames per theme. The user approves them at the gate.
12. **Hook lines (required)** → "Hooks". The user's own list, or you draft them from the opening lines of the winning ads (transcripts) for approval.
13. **USPs and banned words** (a list or a file):
    - the unique selling points creators should highlight (e.g. "ready in 10 minutes", "50 models to choose from"), each with its proof if there is one — the proof stays in your notes;
    - words creators must never use (legal / compliance).

    Don't ask about other brands and don't add a brand rule to the deck.

## Round 4 — Language

14. **Languages:**
    - master language (write it first, get approval);
    - which languages to translate into;
    - who can proofread each one.

    Translations without a native check get flagged to the user.

---

## Gate before building

Show the user, in one message, everything you picked or drafted from their files:

- top videos (product, opening line)
- opening frames
- competitor ads (if asked for)
- products to recommend per market
- themes (setting · story format · hook lines · frames), hook lines, USPs

Wait for "ok" or edits. Only then write brief.json and build. A pick the user rejects is replaced with another of their winning ads or their own choice, never invented.
