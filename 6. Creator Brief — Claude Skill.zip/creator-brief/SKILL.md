---
name: creator-brief
description: "Build a creator brief deck — a mobile slide-deck web page that tells a brand's UGC / affiliate creators what to film and what happens after they upload it to the commission platform (e.g. Trybe). Interviews the user for every input in four rounds, takes the winning ads (delivered by the user, or pulled from the ad account with their permission) plus their files (store data, transcripts, optional competitor ads), turns them into top videos, opening frames, best sellers and competitor references by fixed rules, writes the copy and builds a static deck folder + zip. Trigger: 'creator brief', 'brief for creators', 'UGC creator brief', 'build a creator brief deck', '/creator-brief', 'refresh the creator brief'. NOT for ad copy, static-ad briefs for editors, or creator recruitment pitch decks."
---

# Creator Brief

Builds the brief a creator opens on their phone right after joining a brand's creator program. It is one web page that scrolls slide by slide:

| # | Slide | Built from |
|---|---|---|
| 1 | Hero + index | brand, colours |
| 2 | Vibe & style | default copy |
| 3 | Example shots | top creator videos (+ optional competitor ads that ran longest) |
| 4 | What's selling now | products the user recommends (fallback: store sales ranking) |
| 5 | Themes that sell | ads running and performing now: setting, story format, hook lines, frames |
| 6 | What you can say | the user's USPs + never-say words |
| 7 | Content principles | default copy |
| 8 | Hooks | opening frames of best ads + hook lines + examples |
| 9 | Checklist | default copy |
| 10 | After you upload | commission, payout schedule, launch cadence (tracking text is fixed: last click) |
| 11 | Closing | contact |

Creators upload their videos to the commission platform; they don't post on their own accounts. So there is no posting slide — never add posting steps (professional account, partnership label, branded content, "send us your link").

Any slide without real content disappears, heading included, and the numbering closes up. One market gives a straight page; several markets add a country picker and `?c=XX` deep links.

## Files in this skill

| Path | Use |
|---|---|
| `references/intake.md` | The four question rounds + the approval gate. **Read before asking anything.** |
| `references/selection-rules.md` | How to pick videos, frames, best sellers, competitor ads, themes, hook lines, claims |
| `references/default-copy.md` | English master copy for the fixed sections, to adapt to the product |
| `references/schema.md` | brief.json fields |
| `assets/brief.example.json` | A complete, valid example (fictional brand) — copy its structure |
| `assets/index.html` | The renderer. Never edit per brand; everything brand-specific goes in brief.json |
| `scripts/media.py` | `probe` / `compress` videos / grab the `frame` at 0.4 s (needs ffmpeg) |
| `scripts/build_brief.py` | Validates brief.json and builds the deck folder (+ `--zip`) |

Call scripts by their full path inside this skill folder. Python 3.8+. ffmpeg and yt-dlp are optional — without them, ask the user for ready-made files.

## Workflow

1. **Intake.** Follow `references/intake.md`: Round 1, the winning ads (Q7) and hook lines (Q12) are required; everything else accepts "skip". If the user already attached files, read them first and ask only for what's missing. Keep a list of skipped items.
2. **Turn files into picks** with `references/selection-rules.md`:
   - winning ads → `media.py compress` (top videos) and `media.py frame` (opening frames);
   - store → best sellers;
   - transcripts → themes and hook lines.

   Work in one folder: `brief.json` plus `media/videos`, `media/hooks`, `media/products`.
3. **Gate.** Show every pick and every drafted theme, hook line and claim in one message. Wait for "ok" or edits. Rejected picks are replaced from the same ranked list.
4. **Write the master language.** Use `default-copy.md` adapted to the product, plus the approved picks. Fill every slot from the intake. A slot with no answer means the item is dropped, never guessed.
5. **Translate** to the other languages only after the master is approved. Keep `{tokens}`. Prices come from each market's own store.
6. **Build:**

   ```
   python <skill>/scripts/build_brief.py brief.json --zip
   ```

   - Fix every ERROR and rebuild.
   - WARNs about content (a section missing in one language, a metric in a caption, a heavy file): fix them or tell the user.
7. **Preview.** Open `index.html`. If you have a browser tool, check it at phone size (390×844): every slide readable, videos play muted with a sound button, the picker works if there are several markets.
8. **Deliver:**
   - the folder and zip;
   - the sections that are hidden and why;
   - languages that still need a native proofread;
   - how to host it (any static host; the folder README explains);
   - the refresh cadence: weekly themes, best sellers and frames; monthly videos and competitor ads.

   Publishing is the user's step — never upload or deploy the deck without their explicit go.

## Refresh mode ("refresh the creator brief")

Load the existing `brief.json` and its media folder, ask only for the new winning ads / files, re-run the selection rules for the sections that are due, show the changed picks (gate), rebuild. Everything else stays as approved.

## Hard rules

- **Nothing invented.** Proof, numbers, creator names, claims, prices and product lists come from the user's files or answers. Missing data means the section is hidden, never a placeholder. The build fails on any `[bracket]`, TBD or TODO left in the text.
- **Winning ads come from the user or the ad account.** Either the user delivers them, or — with their permission — you pull the top performers from the ad account by the rule in `selection-rules.md`. Never ask the user to type performance numbers.
- **Nothing internal on the page:** no metrics, payouts or notes.
- **No creator names** on the page; captions show the product.
- **Picks are approved before the build;** translations come after the master is approved.
- **Plain language in the copy:** short sentences, no sales talk. The brief asks creators for natural, unscripted content, so it has to read that way itself.
