#!/usr/bin/env python3
"""Media helpers for the creator brief. Needs ffmpeg + ffprobe on PATH.

  python media.py probe    <file> [<file> ...]
      width x height, duration, size — flags clips too small for a phone screen.

  python media.py compress <video> <out_dir> [--name NAME]
      720 px wide H.264 mp4 (CRF 28, faststart, AAC 96k) + poster jpg taken at 0.4 s.
      Keeps the brief light enough to open on mobile data (aim ≤ 25 MB per clip).

  python media.py frame    <video> <out.jpg> [--at 0.4] [--width 720]
      Opening frame of an ad = what the viewer sees before deciding to scroll.
      Taken from the video file itself: ad platforms' thumbnails are too small.

<video> can also be a public post URL when yt-dlp is installed (resolved with `yt-dlp -g`).
"""
import argparse, json, os, re, shutil, subprocess, sys


def need(tool):
    if not shutil.which(tool):
        sys.exit(f'{tool} not found on PATH. Install it, or ask the user for ready-made files '
                 f'(compressed mp4s / screenshots of the first frame).')


def source(src):
    if re.match(r'^https?://', src) and not re.search(r'\.(mp4|mov|webm|m4v)(\?|$)', src, re.I):
        need('yt-dlp')
        url = subprocess.run(['yt-dlp', '-f', 'best', '-g', src], capture_output=True, text=True)
        if url.returncode != 0 or not url.stdout.strip():
            sys.exit(f'yt-dlp could not resolve {src}: {url.stderr.strip()[:300]}')
        return url.stdout.strip().splitlines()[0]
    return src


def probe(path):
    need('ffprobe')
    r = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                        'stream=width,height:format=duration,size', '-of', 'json', path],
                       capture_output=True, text=True)
    if r.returncode != 0:
        return None
    d = json.loads(r.stdout)
    s = (d.get('streams') or [{}])[0]
    f = d.get('format') or {}
    return {'width': s.get('width'), 'height': s.get('height'),
            'duration': round(float(f.get('duration', 0)), 1), 'mb': round(int(f.get('size', 0)) / 1e6, 1)}


def cmd_probe(a):
    for p in a.files:
        info = probe(p)
        if not info:
            print(f'{p}: not a readable video/image'); continue
        flag = ''
        if info['width'] and min(info['width'], info['height']) < 540:
            flag = '  <- low resolution, will look soft on a phone'
        print(f"{p}: {info['width']}x{info['height']}, {info['duration']}s, {info['mb']} MB{flag}")


def cmd_compress(a):
    need('ffmpeg')
    src = source(a.video)
    os.makedirs(a.out_dir, exist_ok=True)
    name = a.name or os.path.splitext(os.path.basename(a.video.split('?')[0]))[0]
    name = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-') or 'video'
    mp4 = os.path.join(a.out_dir, name + '.mp4')
    jpg = os.path.join(a.out_dir, name + '.jpg')
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', src,
                    '-vf', "scale='min(720,iw)':-2", '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28',
                    '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-c:a', 'aac', '-b:a', '96k', mp4], check=True)
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', '0.4', '-i', mp4, '-frames:v', '1', '-q:v', '3', jpg], check=True)
    info = probe(mp4) or {}
    print(f"{mp4}  ({info.get('width')}x{info.get('height')}, {info.get('mb')} MB)\n{jpg}")


def cmd_frame(a):
    need('ffmpeg')
    src = source(a.video)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', str(a.at), '-i', src, '-frames:v', '1',
                    '-vf', f"scale='min({a.width},iw)':-2", '-q:v', '3', a.out], check=True)
    print(a.out)


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('probe'); p.add_argument('files', nargs='+'); p.set_defaults(fn=cmd_probe)
    c = sp.add_parser('compress'); c.add_argument('video'); c.add_argument('out_dir'); c.add_argument('--name'); c.set_defaults(fn=cmd_compress)
    f = sp.add_parser('frame'); f.add_argument('video'); f.add_argument('out')
    f.add_argument('--at', type=float, default=0.4); f.add_argument('--width', type=int, default=720); f.set_defaults(fn=cmd_frame)
    a = ap.parse_args()
    a.fn(a)


if __name__ == '__main__':
    main()
