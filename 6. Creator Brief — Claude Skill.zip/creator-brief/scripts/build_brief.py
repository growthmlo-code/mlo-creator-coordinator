#!/usr/bin/env python3
"""Validate brief.json and build the creator brief deck folder.

    python build_brief.py brief.json [--media-root DIR] [--out DIR] [--zip] [--check-only]

brief.json  : the content (schema: references/schema.md)
--media-root: folder that local media paths in brief.json are relative to
              (default: the folder brief.json sits in)
--out       : output folder (default: ./creator-brief-<id> next to brief.json)
--zip       : also write <out>.zip
--check-only: validate and report, write nothing

Output folder = index.html + content.js + the media files brief.json references
(and nothing else) + README.md + robots.txt/_headers (noindex).
Exit code 1 when there are errors; warnings never block the build.
"""
import argparse, datetime, json, os, re, shutil, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
RENDERER = os.path.join(HERE, '..', 'assets', 'index.html')
TOKENS = {'brand', 'brandTitle', 'contact', 'store'}
SECTIONS = ['vibe', 'frames', 'bestsellers', 'themes', 'claims', 'principles', 'hooks', 'checklist', 'results']
MAX_VIDEO_MB, MAX_IMAGE_MB = 25, 1.5
VIDEO_EXT = ('.mp4', '.webm', '.mov', '.m4v')

errors, warnings = [], []
def err(msg): errors.append(msg)
def warn(msg): warnings.append(msg)


def is_remote(p):
    return bool(re.match(r'^(https?:)?//|^data:', str(p or '')))


def walk_strings(node, path=''):
    """Yield (path, string) for every string in the tree."""
    if isinstance(node, str):
        yield path, node
    elif isinstance(node, dict):
        for k, v in node.items():
            yield from walk_strings(v, f'{path}.{k}' if path else k)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from walk_strings(v, f'{path}[{i}]')


def has_items(sec):
    return isinstance(sec, dict) and bool(sec.get('items'))


def visible_sections(B, code):
    """Mirror of the renderer's show/hide rules, per language."""
    L = B['langs'][code]
    F = L.get('frames') or {}
    vids = F.get('videos') or B.get('topVideos') or []
    stills = [] if F.get('stills') is False else (B.get('frames') or [])
    refs = (B.get('referenceAds') or []) if F.get('refs') else []
    bs = (B.get('bestSellers') or {}).get(code) or {}
    groups = [g for g in bs.get('groups', []) if g.get('items')]
    cl = L.get('claims') or {}
    H = L.get('hooks') or {}
    ex = L.get('examples') or B.get('examples') or {}
    hooks_any = (bool(B.get('hookFrames')) and H.get('framesTitle')) or (H.get('lines') and H.get('linesTitle')) \
        or (H.get('faceless') and ex.get('faceless')) or (H.get('spoken') and ex.get('spoken'))
    ck = L.get('checklist') or {}
    return {
        'vibe': has_items(L.get('vibe')),
        'frames': bool(F.get('title') and (vids or stills or refs)),
        'bestsellers': bool((L.get('bestsellers') or {}).get('title') and groups),
        'themes': has_items(L.get('themes')),
        'claims': bool(cl.get('title') and (cl.get('items') or cl.get('never'))),
        'principles': has_items(L.get('principles')),
        'hooks': bool(H.get('title') and hooks_any),
        'checklist': bool(ck.get('title') and (ck.get('dos') or ck.get('donts'))),
        'results': has_items(L.get('results')),
    }


def media_refs(B):
    """Every (path-in-brief, value) that points at a media file or link."""
    out = []
    def add(where, v):
        if v: out.append((where, v))
    for i, v in enumerate(B.get('topVideos') or []):
        add(f'topVideos[{i}].url', v.get('url')); add(f'topVideos[{i}].poster', v.get('poster'))
    for i, f in enumerate(B.get('frames') or []):
        add(f'frames[{i}].src', f.get('src'))
    for i, f in enumerate(B.get('hookFrames') or []):
        add(f'hookFrames[{i}].src', f.get('src'))
    for grp, items in (B.get('examples') or {}).items():
        for i, v in enumerate(items or []):
            add(f'examples.{grp}[{i}].url', v.get('url'))
    for code, L in (B.get('langs') or {}).items():
        for i, v in enumerate(((L.get('frames') or {}).get('videos')) or []):
            add(f'langs.{code}.frames.videos[{i}].url', v.get('url')); add(f'langs.{code}.frames.videos[{i}].poster', v.get('poster'))
        for grp, items in (L.get('examples') or {}).items():
            for i, v in enumerate(items or []):
                add(f'langs.{code}.examples.{grp}[{i}].url', v.get('url'))
        for i, t in enumerate(((L.get('themes') or {}).get('items')) or []):
            if isinstance(t, dict):
                for j, src in enumerate(t.get('frames') or []):
                    add(f'langs.{code}.themes.items[{i}].frames[{j}]', src)
    for code, bs in (B.get('bestSellers') or {}).items():
        for gi, g in enumerate(bs.get('groups') or []):
            for i, p in enumerate(g.get('items') or []):
                add(f'bestSellers.{code}.groups[{gi}].items[{i}].img', p.get('img'))
    return out


def validate(B, media_root):
    # --- structure
    brands = B.get('brands') or {}
    if not isinstance(brands, dict) or not brands:
        err('brands: at least one brand is required, e.g. {"main": {"name": "Acme", "title": "Acme", "mark": "Acme"}}')
    for k, b in brands.items():
        if not b.get('name'):
            err(f'brands.{k}.name is empty')
    langs = B.get('langs') or {}
    if not langs:
        err('langs: at least one language is required')
    for code, L in langs.items():
        hero = L.get('hero') or {}
        if not hero.get('title'):
            err(f'langs.{code}.hero.title is empty (use "{{brandTitle}}" to show the brand name)')
        if not hero.get('kicker'):
            err(f'langs.{code}.hero.kicker is empty (e.g. "Creator Brief")')
    countries = B.get('countries') or []
    ids = set()
    for i, c in enumerate(countries):
        for f in ('id', 'name', 'lang'):
            if not c.get(f):
                err(f'countries[{i}].{f} is empty')
        if c.get('id') in ids:
            err(f'countries[{i}].id "{c.get("id")}" is used twice')
        ids.add(c.get('id'))
        if c.get('lang') and c['lang'] not in langs:
            err(f'countries[{i}] uses language "{c["lang"]}" but langs has no "{c["lang"]}" block')
        if brands and c.get('brand') and c['brand'] not in brands:
            err(f'countries[{i}] uses brand "{c["brand"]}" which is not in brands')
    if len(langs) > 1 and not countries:
        warn('several languages but no countries list: one picker entry per language will be generated')
    if countries:
        unused = [code for code in langs if code not in {c.get('lang') for c in countries}]
        if unused:
            warn(f'language(s) {", ".join(unused)} have no entry in countries — nobody can open them')
    theme = B.get('theme') or {}
    for k, v in theme.items():
        if k in ('ink', 'paper', 'accent') and not re.match(r'^#[0-9a-fA-F]{6}$', str(v)):
            err(f'theme.{k} must be a hex colour like #0F172A (got {v!r})')

    # --- leftovers and tokens
    for path, s in walk_strings(B):
        if re.search(r'\[[^\]\n]{1,60}\]', s):
            err(f'{path}: unfilled placeholder in "{s[:80]}"')
        if re.search(r'\b(TBD|TODO|FIXME|lorem ipsum|XXX+)\b', s, re.I):
            err(f'{path}: leftover marker in "{s[:80]}"')
        for tok in re.findall(r'\{(\w+)\}', s):
            if tok not in TOKENS:
                err(f'{path}: unknown token {{{tok}}} (allowed: {", ".join(sorted(TOKENS))})')
            elif tok == 'contact':
                missing = [k for k, b in brands.items() if not b.get(tok)]
                if missing:
                    err(f'{path} uses {{{tok}}} but brand(s) {", ".join(missing)} have no "{tok}" value')

    # --- media
    for where, v in media_refs(B):
        v = str(v)
        if 'vm.tiktok.com' in v or re.search(r'tiktok\.com/t/', v):
            err(f'{where}: TikTok short link will not embed — use the full tiktok.com/@user/video/<id> link')
        if 'drive.google.com' in v:
            warn(f'{where}: Drive links play in Drive\'s own player (with an "open in Drive" button) — a local mp4 gives a clean player')
        if is_remote(v):
            continue
        rel = v.split('?')[0].split('#')[0]
        if rel.startswith('/') or '..' in rel.replace('\\', '/').split('/'):
            err(f'{where}: local paths must be relative and stay inside the media folder ({v})')
            continue
        full = os.path.join(media_root, rel)
        if not os.path.isfile(full):
            err(f'{where}: file not found: {full}')
            continue
        mb = os.path.getsize(full) / 1e6
        if rel.lower().endswith(VIDEO_EXT) and mb > MAX_VIDEO_MB:
            warn(f'{where}: {mb:.0f} MB video — compress it (scripts/media.py compress) so it loads on mobile data')
        elif not rel.lower().endswith(VIDEO_EXT) and mb > MAX_IMAGE_MB:
            warn(f'{where}: {mb:.1f} MB image — resize to ~720 px wide')

    # --- metrics must never reach creators
    metric = re.compile(r'\b(ROAS|CPA|CPM|CTR|AOV|spend|hook rate|thumb.?stop)\b|\b\d+(\.\d+)?x\b', re.I)
    caption_fields = []
    for i, v in enumerate(B.get('topVideos') or []): caption_fields.append((f'topVideos[{i}].title', v.get('title')))
    for i, f in enumerate(B.get('hookFrames') or []):
        caption_fields += [(f'hookFrames[{i}].name', f.get('name')), (f'hookFrames[{i}].product', f.get('product'))]
    for i, f in enumerate(B.get('frames') or []): caption_fields.append((f'frames[{i}].caption', f.get('caption')))
    for path, val in caption_fields:
        for p, s in walk_strings(val, path):
            if metric.search(s):
                warn(f'{p}: looks like a performance metric in a caption creators will see ("{s[:60]}")')

    # --- size sanity
    if len(B.get('hookFrames') or []) > 12: warn('hookFrames: more than 12 frames — keep the best 10')
    if len(B.get('topVideos') or []) > 12: warn('topVideos: more than 12 videos — keep the best 5-10')

    # --- per-language coverage
    if langs:
        vis = {code: visible_sections(B, code) for code in langs}
        for s in SECTIONS:
            on = [c for c in langs if vis[c][s]]
            if on and len(on) != len(langs):
                off = [c for c in langs if c not in on]
                warn(f'section "{s}" shows in {", ".join(on)} but is hidden in {", ".join(off)}')
        return vis
    return {}


README = """# {brand} — Creator Brief

Open `index.html` in a browser to preview. Everything creators read comes from `content.js`;
`index.html` only renders it. Sections with no content hide themselves.

## Sharing
Upload this whole folder to any static host (Netlify drag-and-drop, Vercel, Cloudflare Pages,
GitHub Pages). Keep the files together — `content.js` and the media sit next to `index.html`.
The page is set to noindex (robots.txt, _headers, meta tag), but anyone with the link can open it.

{links}

## Updating
Do not edit `content.js` by hand if you have the source `brief.json` — change `brief.json` and run
`build_brief.py` again: it re-validates and changes the cache version, so creators see the new copy.
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('brief')
    ap.add_argument('--media-root')
    ap.add_argument('--out')
    ap.add_argument('--zip', action='store_true')
    ap.add_argument('--check-only', action='store_true')
    a = ap.parse_args()

    brief_path = os.path.abspath(a.brief)
    try:
        B = json.load(open(brief_path, encoding='utf-8'))
    except json.JSONDecodeError as e:
        print(f'ERROR brief.json is not valid JSON: {e}'); sys.exit(1)
    media_root = os.path.abspath(a.media_root or os.path.dirname(brief_path))
    vis = validate(B, media_root)

    slug = re.sub(r'[^a-z0-9]+', '-', str(B.get('id') or B.get('brand') or 'brief').lower()).strip('-') or 'brief'
    out = os.path.abspath(a.out or os.path.join(os.path.dirname(brief_path), f'creator-brief-{slug}'))

    print(f'Brief: {B.get("brand") or slug} · languages: {", ".join(B.get("langs", {}))}')
    for code, v in vis.items():
        shown = [s for s in SECTIONS if v[s]]
        hidden = [s for s in SECTIONS if not v[s]]
        print(f'  [{code}] shows {len(shown)}: {", ".join(shown)}' + (f'  | hidden: {", ".join(hidden)}' if hidden else ''))
    for w in warnings: print('WARN  ' + w)
    for e in errors: print('ERROR ' + e)
    if errors:
        print(f'\n{len(errors)} error(s) — nothing written.'); sys.exit(1)
    if a.check_only:
        print('\nCheck passed (nothing written: --check-only).'); return

    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out)
    version = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    html = open(RENDERER, encoding='utf-8').read().replace('__VERSION__', version)
    title = (B.get('brand') or 'Creator') + ' — Creator Brief'
    html = html.replace('<title>Creator Brief</title>', f'<title>{title}</title>', 1)
    open(os.path.join(out, 'index.html'), 'w', encoding='utf-8').write(html)
    with open(os.path.join(out, 'content.js'), 'w', encoding='utf-8') as f:
        f.write(f'/* Generated by build_brief.py on {version} from brief.json — edit brief.json, not this file. */\n')
        f.write('window.BRIEF = ' + json.dumps(B, ensure_ascii=False, indent=1) + ';\n')

    copied = set()
    for _, v in media_refs(B):
        if is_remote(v):
            continue
        rel = str(v).split('?')[0].split('#')[0]
        if rel in copied:
            continue
        dst = os.path.join(out, rel)
        os.makedirs(os.path.dirname(dst) or out, exist_ok=True)
        shutil.copy2(os.path.join(media_root, rel), dst)
        copied.add(rel)

    open(os.path.join(out, 'robots.txt'), 'w').write('User-agent: *\nDisallow: /\n')
    open(os.path.join(out, '_headers'), 'w').write('/*\n  X-Robots-Tag: noindex, nofollow\n')
    countries = B.get('countries') or []
    links = ''
    if len(countries) > 1:
        links = 'Direct link per market (skips the country picker):\n' + '\n'.join(
            f'- {c["name"]}: `?c={c["id"]}`' for c in countries)
    open(os.path.join(out, 'README.md'), 'w', encoding='utf-8').write(
        README.format(brand=B.get('brand') or slug, links=links))

    size = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(out) for f in fs) / 1e6
    print(f'\nBuilt {out}  ({len(copied)} media files, {size:.1f} MB)')
    if a.zip:
        zp = out + '.zip'
        with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
            for dp, _, fs in os.walk(out):
                for f in fs:
                    full = os.path.join(dp, f)
                    z.write(full, os.path.relpath(full, os.path.dirname(out)))
        print(f'Zipped {zp}')


if __name__ == '__main__':
    main()
